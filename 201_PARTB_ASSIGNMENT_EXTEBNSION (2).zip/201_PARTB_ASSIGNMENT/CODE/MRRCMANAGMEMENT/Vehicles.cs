﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;
using System.Xml.Schema;
namespace MRRCMANAGMEMENT
{
    /// <summary>
    /// 
    /// The vehicle class describes the attributes' data types :
    /// registration : string , string : model , string : make , string : color , fuel_type : fuel , Transmission_Type : transmission , Vehicle_Grade : grade 
    /// int : year , int : no_seats , double : hire_rate, bool : GPS, sunroof 
    /// 
    /// Although not all of them are used 
    /// 
    /// =================================================================================================================================================
    /// 
    /// It also defines a bool create which makes sure the inputs are valid . 
    /// Returns true : if the inputs are valid .  Returns false : if inputs are unvalid
    /// 
    /// ==================================================================================================================================================
    /// 
    /// The int vehicle_attributes defines the number of attributes the vehicle has . 
    /// 
    /// ==================================================================================================================================================
    /// 
    /// The class inherits from the Types_specification class to define the fuel type ,transmission  type and car grade 
    /// 
    /// 
    /// ===================================================================================================================================================
    /// 
    /// The class also has one constructor which checks the registration , the seats, year and hire rate  
    /// 
    /// </summary>
    public class Vehicle : Types_specification
    {
        private string registration;
        private string model;
        private string make;
        private string color;
        private Fuel_Type fuel;
        private Vehicle_Grade grade;
        private Transmission_Type transmission;
        private int year, no_seats;
        private double hire_rate;
        private bool GPS, sunroof;
        private bool create = true;
        public int vehicle_attributes = 12;
        public string grade_search;
        public string transmission_search;
        public string year_search;
        public string fuel_search;
        public string GPS_search;
        public string Sunroof_search;
        public string Seats_search;
        public string make_search;
        public string model_search;
        public string color_search;
        string daily_rate_search;

        public bool Create_
        {
            get { return create; }
            set
            {
            }
        }
        // This property checks if the registration number is in the correct form *123RED* ( 3 numbers followed by 3 letters) 
        public string Reg
        {
            get
            {
                return registration;
            }
            set
            {
                char[] reg_Check = value.ToCharArray(); // Converting the reg number to a character array 
                int i = 0;
                bool proceed = true; //  Declaring and initialising a bool to make sure to proceed with the checks
                bool result; // bool to check the if the characters of the char array are in the same format as intended 
                if (reg_Check.Length == 2) // Checking the length of the reg number to be 6 
                {
                    while (i < 3) // using a while loop to check if the first three characters of the given reg no are numerical values 
                    {
                        result = char.IsNumber(reg_Check[i]);
                        if (!result)
                        {
                            proceed = false;
                            create = false;
                            Console.WriteLine("\n ERROR : Enter a valid  registration number *123abc* ");
                            break;
                        }
                        i++;
                    }
                    if (proceed == true) // If the first three characters are numerical proceed to check the other three 
                    {
                        while (i < 2)
                        {
                            result = char.IsNumber(reg_Check[i]);
                            if (result)
                            {
                                proceed = false;
                                create = false;
                                Console.WriteLine("\n ERROR : Enter a valid  registration number *123abc* ");
                                break;
                            }
                            i++;
                        }
                    }
                    if (proceed == true) // if the input is correct set the value equal to the reg value 
                    {
                        create = true;
                        registration = value;
                    }
                }
                else
                {
                    create = false; // else set the create boolean as false. 
                    Console.WriteLine("\n ERROR : Enter a valid  registration number *123abc* ");
                }
            }
        }
        public string Colour
        {
            get
            {
                return color;
            }
            set
            {
                color = value;
                if (value == "") // If no value is given , set the default to Black 
                {
                    color = "Black";
                    Console.WriteLine("\n DEFAULT SET : Color set to Black by default");
                }
            }
        }
        public bool GPS_
        {
            get
            {
                return GPS;
            }
            set
            {
                GPS = value;
            }
        }
        public bool Sunroof_
        {
            get
            {
                return sunroof;
            }
            set
            {
                sunroof = value;
            }
        }
        // Checking if the car year is not negative 
        public int Year
        {
            get
            {
                return year;
            }
            set
            {
                if (value < 0)
                {
                    create = false;
                    Console.WriteLine($"\n ERROR : Year cannot be negative {value} ");
                }
                else
                {
                    year = value;
                }
            }
        }
        // Checking the hire rate > 0 
        public double Daily_rate
        {
            get
            {
                return hire_rate;
            }
            set
            {
                hire_rate = value;
                if (value < 0)
                {
                    create = false;
                    Console.WriteLine($"\n ERROR : Daily_rate cannot be negative {value}");
                }
            }
        }
        public string Model
        {
            get { return model; }
            set
            {
                model = value;
            }
        }
        public string Make
        {
            get { return make; }
            set
            {
                make = value;
            }
        }
        public Vehicle_Grade Grade_
        {
            get { return grade; }
            set
            {
                grade = value;
            }
        }
        // The property checks if the seats <0 , less than 2 or greater than 10 
        public int Seats
        {
            get
            {
                return no_seats;
            }
            set
            {
                no_seats = value;
                if (value < 0)
                {
                    create = false;
                    Console.WriteLine($"\n ERROR : Number of seats cannot be negative : {value} ");
                }
                else if (value < 2 | value > 10)
                {
                    create = false;
                    Console.WriteLine($"\n ERROR : Number of seats cannot be LESS THAN 2 OR MORE THAN 10 :  {value} ");
                }
            }
        }
        public Transmission_Type Transmission
        {
            get
            {
                return transmission;
            }
            set
            {
                transmission = value;
            }
        }
        public Fuel_Type Fuel
        {
            get { return fuel; }
            set
            {
                fuel = value;
            }
        }

        // The constructor asks for the mandatory parameters and sets them to the respective properties 
        public Vehicle(string reg, Vehicle_Grade grade_, string vehicle_make, string vehicle_model,
                       int vehicle_year)
        {
            this.Reg = reg;
        }


        // Vehicle(string vehicleCSV):  used in the Search,cs file : for the matching vehicle attributes to the given attributes in the query 
        public Vehicle(string vehicleCSV)
        {
            // vehicle constructor from CSV string
            ArrayList values = new ArrayList();
            values.AddRange(vehicleCSV.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
            // Assigning values to variables. gettting rid of spaces.
            registration = values[0].ToString().Replace(" ", "");
            grade_search = values[1].ToString().Replace(" ", "");
            make_search = values[2].ToString().Replace(" ", "");
            model_search = values[3].ToString().Replace(" ", "");
            year_search = values[4].ToString().Replace(" ", "") + "-YEAR";
            Seats_search = values[5].ToString().Replace(" ", "") + "-SEATER";
            transmission_search = values[6].ToString().Replace(" ", ""); ;
            fuel_search = values[7].ToString().Replace(" ", "");
            // Replacing "TRUE" and "FALSE" values to match the query tokens 
            if (values[8].ToString().ToUpper() == "TRUE")
            {
                GPS_search = (string)"GPS";
            }
            if (values[8].ToString().ToUpper() == "FALSE")
            {
                GPS_search = (string)"NOGPS";
            }
            if (values[9].ToString().ToUpper() == "TRUE")
            {
                Sunroof_search = (string)"SUNROOF";
            }
            if (values[9].ToString().ToUpper() == "FALSE")
            {
                Sunroof_search = (string)"NOSUNROOF";
            }

            daily_rate_search = (string)values[10];
            color_search = (string)values[11];
        }

        // Display matched vehicles with all their attributes. 
        public override string ToString()
        {
            if (Sunroof_search.Equals("NOSUNROOF")) // Getting the space back when displaying the details of matched vehicles
            {
                Sunroof_search = "NO SUNROOF";
            }
            if (GPS_search.Equals("SUNROOF"))
            {
                Sunroof_search = "NO SUNROOF";
            }
            string display = "\n\n" +

                (String.Format("{0,-21} {1,-20} {2,-18} {3,-16} {4,-14} {5,-12} {6,-10} {7,-8} {8,-6} {9,-4} {10,-2} {11,-0}", registration, grade_search, make_search, model_search, year_search,
                transmission_search + "    ", fuel_search + "    ", Seats_search + "     ",
                GPS_search + "  ", Sunroof_search + "     ", daily_rate_search + "   ", color_search));
            return display;
        }
    }
}
