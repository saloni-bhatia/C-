﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;


namespace MRRCMANAGMEMENT
{
    /// <summary>

    /// Rental_Management class contains all the mentods to tackle all the user's requirements for the rental menu 
    /// Rent_Vehicle() : Rent a vhicle only if it has not been rented or the customer does not already rent any vehicle  
    /// Return_Vehicle() : Returns the vehicle, only if the vehicle was rented, and the customer was renting that particular vehicle 
    /// Search_Vehicle() : Search teh queries, using Shlomo Geva's code desribed in RPN.cs and Search.cs
    /// Display_Rental() : Displays the rented vehicles , the customers renting them and the daily cost of the vehicles, taken from the fleet flie. 

    /// </summary>

    class Rental_management
    {
        File_Manipulation Read_attributes = new File_Manipulation();//Object initialisation to use methods from class 
        const int attributes_num_rental = 2;// The number of attributes present in the rental file 


        //~~~~~~~~~~~~~ Method to rent a vehicle~~~~~~~~~~~~~~~~~~~~~
        //
        // 1. Get Details for the vehicle to be rented, confirm the vehicle exists in the database. 
        // 2. Check if the vehicle is being rented or not 
        // 3. If vehicle is available, get the customer number, do validation checks
        // 4. If renting is successful, write to the file. Else display message
        public bool Rent_Vehicle()
        {
            bool can_rent = true; // boolean to confirm success 
            int reg_being_rented = 0; // Variable to store the registration number of car rented 
            string given_reg, given_customer = "";// Strings to store inputs
            Console.WriteLine("\n  ~~~~~ Enter the following details to rent a vehicle ~~~~ \n");
            Console.WriteLine();
            Console.Write("Registration Id : ");
            given_reg = Console.ReadLine().ToUpper();
            List<string> validation_ids = new List<string>();// List to store registrations and cust ids
            List<string> daily_cost = new List<string>();// List to store daily costs fom the fleet file
            // 12 = number of attributes in the fleet file.
            validation_ids = Read_attributes.attributes_list(1, 12, 12); //reading the reg numbers of the fleet file
            if (validation_ids.Contains(given_reg)) // Checking if the given registration number exists in the datatbase
            {
                reg_being_rented = validation_ids.IndexOf(given_reg);//retaining the index of given reg. no to find the corresponding daily rate
                validation_ids.RemoveRange(0, validation_ids.Count());// Empty the list 
                validation_ids = Read_attributes.attributes_list(3, attributes_num_rental, attributes_num_rental);//Getting the reg no from the Rental file 
                try
                {
                    if (validation_ids.Contains(given_reg))// Checking if the given vehicle is already rented
                    {
                        can_rent = false;// Cannot rent if already rented
                        throw new Exception();//throw exception 

                    }
                    else
                    {
                        Console.Write("\nCustomer ID: ");
                        given_customer = Console.ReadLine().ToUpper();
                        try
                        {
                            if (!Int32.TryParse(given_customer, out int is_int))// If the customer id is not an int 
                            {
                                throw new Exception();//throw exception
                            }
                            else
                            {
                                if (is_int < 0)// if given id < 0
                                {
                                    throw new Exception();
                                }
                            }
                        }
                        catch (Exception) // Catch the above exceptions
                        {
                            Console.WriteLine("\n\n The customer ID should be a positive integer ");
                            can_rent = false;
                        }
                        if (can_rent == true) // If all ids are valid, no exceptions are thrown
                        {
                            validation_ids.RemoveRange(0, validation_ids.Count());//Empty the list
                            validation_ids = Read_attributes.attributes_list(3, attributes_num_rental - 1, attributes_num_rental - 1);//getting the Customer id's who have already rented 
                            if (validation_ids.Contains(given_customer)) // If the given cust id already rents 
                            {
                                can_rent = false;
                                Console.Write("\n\n The customer with the given ID is already renting a vehicle \n");
                            }
                            else
                            {
                                validation_ids.RemoveRange(0, validation_ids.Count());
                                validation_ids = Read_attributes.attributes_list(2, 6, 6);//getting all the cust ids from the database
                                try
                                {
                                    if (!validation_ids.Contains(given_customer))// if the given customer is not in database 
                                    {
                                        can_rent = false;
                                        Console.WriteLine($"\n\n The customer with the customer ID {given_customer} does not exist in the database \n");
                                    }
                                    else
                                    {
                                        Console.Write("\nRental Time (days): ");
                                        string rental_time = Console.ReadLine();
                                        int rental_timeINT = 0;
                                        try
                                        {
                                            if (!Int32.TryParse(rental_time, out rental_timeINT)) // Check if the rental time is an int.
                                            {
                                                throw new FormatException();//trow exception for not being an int
                                            }
                                            else
                                            {
                                                if (rental_timeINT <= 0)
                                                {
                                                    throw new DivideByZeroException();// throw exception for not being positive and > 0 
                                                }
                                            }
                                        }
                                        catch (FormatException) // Catching the exceptions
                                        {
                                            Console.WriteLine($"\n\nThe rental time must be an integer");
                                            can_rent = false;
                                        }
                                        catch (DivideByZeroException)
                                        {
                                            can_rent = false;
                                            Console.WriteLine("\n\n The rental time must  be an integer greater than zero");
                                        }
                                        if (can_rent == true)
                                        {  /// 22 = first occurance of the daily rate 
                                            daily_cost = Read_attributes.attributes_list(1, 12, 22);// getting the daily rates 
                                            double daily_total_cost = rental_timeINT * (double.Parse(daily_cost[reg_being_rented])); // Get the corresponding daily rate
                                            Console.WriteLine($"\n\nTotal daily cost = {daily_total_cost}"); // Displaying the final cost 
                                        }
                                    }
                                }
                                catch (Exception Except)// carch any exception, if any left 
                                {
                                    Console.WriteLine(Except.Message);
                                }
                            }// end else
                        }// end if (all validations)
                    }// end else 
                }//try

                catch (Exception)
                {
                    Console.Write("\n\n The car is already rented ! ");
                }
            }// end if( reg no exists in database)

            else
            {
                can_rent = false;
                Console.WriteLine($"\n \n Vehicle with the given registration number {given_reg} does not exist \n\n ");
            }

            if (can_rent == true) // if car is being rented 
            {
                File_Manipulation write_rented = new File_Manipulation();
                List<string> attributes = new List<string>();
                string[] attributes_added = { given_reg, given_customer };// Add the attributes of the rented vehicle
                Console.WriteLine("\n The vehicle was rented !\n");
                write_rented.Table(3 * (attributes_added.Length)); // Displaying the rented vehicle
                Console.WriteLine();
                Console.Write(" ");
                for (int i = 0; i < attributes_added.Length; i++)
                {
                    Console.Write(attributes_added[i] + "    ");
                }
                Console.WriteLine();
                write_rented.Table(3 * (attributes_added.Length));
                Console.WriteLine();
                attributes = write_rented.Csv_File(attributes_added, 2); // Getting a CSV file of the attributes
                write_rented.ReadFile(write_rented.Path[3]);
                if (write_rented.Proceed == false)
                {
                    write_rented.Proceed = true;
                    write_rented.ReadFile(write_rented.Path[3]);

                }

                if (write_rented.Read_file.Count() > 1)
                {
                    write_rented.WriteFile(write_rented.Path[3], attributes);//Writing into file
                }
                else
                {
                    write_rented.WriteFile_New(write_rented.Path[3], attributes);//Writing into file
                }
            }
            return can_rent;
        }

        ////~~~~~~~~~~~~~ Method to return  a vehicle~~~~~~~~~~~~~~~~~~~~~
        ///1. Get Details of the customer , check if the customer is renting a vehicle  
        // 2. Get the vehicle id , Check if the vehicle is being rented or not 
        // 3.  If renturning is successful, write to the file. Else display message

        public bool Return_Vehicle()
        {
            bool returned = true; // bool making sure if vehicle retur successful
            string given_reg = "";
            string message = "";
            int index_vehicle = 0; //int used to save the index o the vehicle found
            int index_customer = 0;// stores index of customer id found 
            Console.WriteLine("\n  ~~~~~ Enter the following details to rent a vehicle ~~~~ \n");
            Console.Write("Customer ID : ");
            string given_customer = Console.ReadLine();
            List<string> validation_ids = new List<string>();
            // check if customer is renting a vehicle 
            validation_ids = Read_attributes.attributes_list(3, attributes_num_rental - 1, attributes_num_rental - 1);// getting just the customer ids
            try
            {
                if (!validation_ids.Contains(given_customer)) // if the customer is not renting any vehicle   
                {
                    returned = false;
                    message = ($"\n\nThe customer with the given ID {given_customer} is not renting a vehicle \n");// Store the message for exceptions 
                    throw new Exception(); // throw  exception
                }

                else
                {
                    index_customer = validation_ids.IndexOf(given_customer) / 2; // divinding the index ,since the list contains vehicles being rented also 
                    Console.Write("\nRegistration number : ");
                    given_reg = Console.ReadLine().ToUpper();
                    validation_ids.RemoveRange(0, validation_ids.Count()); // clear the list 
                    validation_ids = Read_attributes.attributes_list(3, attributes_num_rental, attributes_num_rental);// getting the registration number for rented vehicles 

                    if (!validation_ids.Contains(given_reg))// If vehicle is not being rented 
                    {
                        returned = false;
                        message = ($"\nVehicle with the registration number {given_reg} was not rented");
                        throw new Exception();
                    }

                    else
                    {
                        index_vehicle = validation_ids.IndexOf(given_reg); // geting the index 
                        if (index_customer - 1 == index_vehicle)// subtracting 1 to get the vehicle id. 
                        {
                            Console.Write("\nAre you sure you want to return the vehicle? (Y: YES , N:NO)");
                            string confirmation = Console.ReadLine().ToUpper();
                            if (confirmation == "Y")// making sure to return s
                            {
                                returned = true;
                            }
                            else
                            {
                                returned = false;
                            }
                        }
                        else
                        {
                            returned = false;
                            message = ($"\nGiven customer {given_customer} is not renting the given vehicle {given_reg}");
                            throw new Exception();

                        }
                    }
                }


                if (returned == true)
                {
                    File_Manipulation write_returned = new File_Manipulation();
                    write_returned.ReadFile(write_returned.Path[3]);
                    if (write_returned.Proceed == false)
                    {
                        write_returned.Proceed = true;
                        write_returned.ReadFile(write_returned.Path[3]);

                    }
                    int index_rentalFile = write_returned.Read_file.IndexOf(given_reg);
                    write_returned.Read_file.RemoveRange(index_rentalFile, attributes_num_rental);
                    string[] rental_returned = write_returned.Read_file.ToArray();
                    write_returned.WriteFile_New(write_returned.Path[3], write_returned.Csv_File(rental_returned, 2));
                    Console.WriteLine("\nThe vehicle was Returned!\n");
                }
            }

            catch (Exception)
            {
                Console.WriteLine(message);
            }

            return returned;

        }


        ////~~~~~~~~~~~~~ Method to Search a vehicle~~~~~~~~~~~~~~~~~~~~~ 
        public void Search_Vehicle()
        {
            EXECUTE_RPN.Search search_query = new EXECUTE_RPN.Search(); // using the code in RPN to search
            search_query.Process();

        }
        ////~~~~~~~~~~~~~ Method to Display rentals ~~~~~~~~~~~~~~~~~~~~~ 

        public void Display_Rental()
        {
            File_Manipulation rental_file = new File_Manipulation();
            rental_file.ReadFile(rental_file.Path[3]);
            if (rental_file.Proceed == false) // default path set of fole does npt exist
            {
                rental_file.Proceed = true;
                rental_file.ReadFile(rental_file.Path[3]);

            }
            int keep_track = 0; int index = 0; int attributes = 0;
            int length_file = (rental_file.Read_file.Count);

            if (length_file <= 1)
            {
                Console.WriteLine("\n There are no vehicles stored \n");
            }

            else
            {
                int width = ("  " + rental_file.Read_file[0] + "  ").Length; // initialising the width of the cell of the table
                rental_file.Table(width);
                Console.WriteLine();
                List<string> daily_rate = rental_file.attributes_list(1, 12, 22);// getting the daily rates
                                                                                 // 12 = attributes of vehicle file
                List<string> registration_no = rental_file.attributes_list(1, 12, 12);// getting the reg_nos.
                int match_registraton = 0;
                bool display = false; // boolean used to  correspond the daily rate with teh registration numbers in the rental file 
                while (keep_track < length_file)
                {
                    for (; attributes < attributes_num_rental; index++)
                    {
                        if (index < length_file)
                        {
                            // making sure the cells are of same size
                            width = Math.Abs(rental_file.Read_file[index].Length - (rental_file.Read_file[0].Length));
                            string width_ = "";
                            //making a string that is of the size of the difference between the ideal and the present width
                            for (int i = 0; i < width; i++)
                            {
                                width_ += " ";
                            }
                            Console.Write("  " + rental_file.Read_file[index] + width_ + " |");
                            if (index == 1)
                            {
                                Console.Write("  " + "Daily Rate" + width_);// header to display
                            }
                            if (registration_no.Contains(rental_file.Read_file[index]))
                            {
                                display = true;
                                match_registraton = registration_no.IndexOf(rental_file.Read_file[index]);
                            }
                            attributes++;
                            width = ("  " + rental_file.Read_file[index] + width_ + " |").Length;
                        }
                        else
                        {
                            break;
                        }
                    }
                    if (display == true)
                    {

                        Console.Write("  " + daily_rate[match_registraton]);// get the daily rate 
                    }

                    Console.WriteLine();
                    rental_file.Table(width);
                    attributes = 0;
                    keep_track += attributes_num_rental;

                    // updating the index for the loop by the number of  vehicle's attributes 
                    Console.WriteLine();
                }
            } //end else statement
        }// end display
    }//end class
}//end namespace 
