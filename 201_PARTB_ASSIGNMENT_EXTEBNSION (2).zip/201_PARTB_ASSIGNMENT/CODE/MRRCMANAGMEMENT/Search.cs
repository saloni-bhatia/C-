﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.IO;
using static System.Console;
using myRPN;
using System.Globalization;
using MRRCMANAGMEMENT;

/* ACKNOWLEDGEMENT 

      The following code is directly taken from Shlomo Geva's code (WEEK 8 LECTURES : Searching).
      Changes have been done to match the requirements for the project
      
*/


namespace EXECUTE_RPN
{

    // Search : The class has multiple methods to help complete the seatch functionality of the project. 
    public class Search
    {
        public const int attributes_num_vehicle = 12;
        public const int attributes_num_rental = 2;
        // Process () : sets up the fleet describes in teh setUpVehicles() method, gets the query and calls the search(RPN,Set_Attributes_vehicles) if the query is not empty
        public void Process()
        {
            setUpVehicles(out Set_Attributes_vehicles fleet); // set up a vehicles fleet
            while (true) // forever or until user quits
            {
                try
                {
                    getQuery(out ArrayList query); // get the query 
                    if (query.ToArray().Length == 0) // Display all non - rented vehicles if the query is blank 
                    {
                        File_Manipulation vehicles_display = new File_Manipulation();
                        vehicles_display.ReadFile(vehicles_display.Path[1]);
                        if (vehicles_display.Proceed == false)
                        {
                            vehicles_display.Proceed = true;
                            vehicles_display.ReadFile(vehicles_display.Path[1]);

                        }// read the fleet file
                        // attributes_num_rental = number of attributes of the rental file
                        List<string> rented_vehicle = vehicles_display.attributes_list(3, attributes_num_rental, 2);// get the registration no. from the rentals file

                        for (int match_registrationn = 0; match_registrationn < vehicles_display.Read_file.Count;)
                        {
                            for (int is_rented = 0; is_rented < rented_vehicle.Count; is_rented++)
                            {
                                if (vehicles_display.Read_file[match_registrationn] == rented_vehicle[is_rented])
                                {
                                    vehicles_display.Read_file.RemoveRange(match_registrationn, attributes_num_vehicle);// remove the vehicles which are rented : get available vehicles

                                }
                            }
                            // attributes_num_vehicle = number of attributes of the vehicle
                            match_registrationn += attributes_num_vehicle;
                        }

                        vehicles_display.Table(vehicles_display.Read_file, 4, 12);// Display as a table using the Table method
                    }

                    else if (query[0].Equals("QUIT")) // go back to the main menu if user decided to quit 
                    {
                        WriteLine("Bye!\n\n");
                        Menu_ go_back = new Menu_();
                        go_back.Home();
                        break;
                    }
                    else
                    {
                        search(new RPN(query), fleet); // convert query to RPN and search
                    }
                }
                catch (Exception e)
                {
                    WriteLine(e.Message);// if an exception is thrown , display approriate message
                }
            }

            // The following method sets up a fleet of all the vehicles.
            void setUpVehicles(out Set_Attributes_vehicles fleetVehicles)
            {
                MRRCMANAGMEMENT.File_Manipulation vehicles = new MRRCMANAGMEMENT.File_Manipulation();
                List<string> vehicle_list = vehicles.attributes_list(1, 1, attributes_num_vehicle);// get details fron the fleet file
                List<string> set_up_vehicles = new List<string>();
                for (int i = 0; i < vehicle_list.Count - 1;)
                {
                    string s = "";
                    for (int j = i; j < (i + attributes_num_vehicle); j++)
                    {
                        s = s + vehicle_list[j] + ",";
                    }
                    set_up_vehicles.Add(s);
                    i = i + 12;//attributes_num_vehicle= number of attributes of a  vehicle
                }
                string[] vehicles_array = set_up_vehicles.ToArray();
                fleetVehicles = new Set_Attributes_vehicles();
                for (int i = 0; i < vehicles_array.Length; i++)
                {
                    fleetVehicles.insertVehicle(vehicles_array[i]);
                }
            }

            // The following method gets the matched vehicles and displays them using the displayVehicle(string) method
            void search(RPN rpn, Set_Attributes_vehicles flt)
            {
                WriteLine("\n------------ Searching ----------");
                WriteLine();
                WriteLine();
                flt.search(out string[] result, rpn);// search the fleet
                if (result.Length == 0)
                    throw new Exception("No match found"); // throw exception when no vehicle is found 
                foreach (string v in result)
                {
                    flt.displayVehicle(v);// display matched vehicles
                }
            }

            // The following method gets the quey and converts it intp an array list 
            string getQuery(out ArrayList query)
            {
                // accept user query and do validation checks
                query = new ArrayList();
                string queryText = ""; // string stores the formatted query 
                bool add_to_query = false;// bool used to format  spaced queries
                string spaced_query = "";// saving spaces queries 
                int k = 0; // int used to save the index of required token 
                Console.Write("\nEnter your query (Press Enter to display all available vehicles), or Q to Quit:  ");
                string temp = Console.ReadLine().ToUpper();
                // Until the user quuits
                if (temp.ToUpper() != "Q")
                {
                    // separate parenthesis before splitting string
                    for (int i = 0; i < temp.Length; i++)
                    {
                        if (temp[i].Equals('(') || temp[i].Equals(')'))
                        {
                            queryText += " ";
                            queryText += temp[i];
                            queryText += " ";
                        }
                        // If a space is encountered : This was implememnted to search when the attributes contain spaces     
                        else if (temp[i].Equals(' '))
                        {
                            bool stop = false;// To stop the loop when required 
                            while (stop == false)
                            {
                                int j = i + 1;// getting the next index for temp 
                                if (j <= temp.Length - 1)// until the code spans over the whole query
                                {
                                    spaced_query = "";// resetting to blank
                                    while (true)
                                    {
                                        if (temp[j] != ' ')// if the next value is also a space 
                                        {
                                            spaced_query += temp[j];// add to the string
                                            j++;// increment j 
                                        }
                                        else
                                        {
                                            stop = true;
                                            break;
                                        }
                                        if (spaced_query == "AND" | spaced_query == "OR")// if the next word after the space is an operator 
                                        {
                                            k = i;// store the current index 
                                            add_to_query = true;// adds the space to the query text after exiting the loop
                                            stop = true;// break the first loop
                                            break;// get out of this loop

                                        }

                                        if (j >= temp.Length) // quey has been evaluated 
                                        {
                                            k = i;
                                            stop = true;
                                            break;
                                        }
                                    }
                                }

                                else { break; }
                            }

                        }
                        else
                        {
                            if (add_to_query)
                            {
                                queryText += temp[k];// add the token
                                add_to_query = false;// reset bool
                                i = i - 1;// get back to the index 
                            }
                            else
                            {
                                queryText += temp[i]; // add the query token
                                if (queryText.EndsWith("OR") | queryText.EndsWith("AND")) // if it was an AND / OR 
                                {
                                    queryText += " ";// Add a space after the operator 
                                }
                            }

                        }
                    }
                    queryText = queryText.ToUpper();

                    query.AddRange(queryText.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));// Split as spaces 

                }
                else
                {
                    query.Add("QUIT");// of the user enters "Q"
                }
                return temp;
            } // end getQuery()
        } // end Main()
    } // end Program class


    // Set_Attributes_vehicles :  maintaining a vehicles list to be searched later , and setting attribute  for lookup
    //Other methods described later to display and search 
    class Set_Attributes_vehicles
    {
        public const int attributes_num_vehicle = 12;
        public const int attributes_num_rental = 2;
        ArrayList vehicles; // vehicles in the fleet
        SortedList attributeSets; // sets of vehicles  with a given attribute value
        public int Length
        {
            get
            {
                return vehicles.Count;
            }
        }
        public Set_Attributes_vehicles()
        {
            vehicles = new ArrayList();
            attributeSets = new SortedList();

            //getting distinct attributes from the file 

            MRRCMANAGMEMENT.File_Manipulation operands_from_file = new MRRCMANAGMEMENT.File_Manipulation();
            //colors
            List<string> Color = (operands_from_file.attributes_list(1, 12, 23)).Distinct().ToList();
            //Model
            List<string> Model = ((operands_from_file.attributes_list(1, 12, 15)).Distinct().ToList());
            //Make
            List<string> Make = (operands_from_file.attributes_list(1, 12, 14)).Distinct().ToList(); ;
            //Grade
            List<string> Grade = (operands_from_file.attributes_list(1, 12, 13)).Distinct().ToList(); ;
            //fuel
            List<string> Fuel = (operands_from_file.attributes_list(1, 12, 19)).Distinct().ToList(); ;
            //transmission
            List<string> Transmission = (operands_from_file.attributes_list(1, 12, 18)).Distinct().ToList();
            //sunroof
            List<string> Sunroof = (operands_from_file.attributes_list(1, 12, 21)).Distinct().ToList();
            //GPS
            List<string> GPS = (operands_from_file.attributes_list(1, 12, 20)).Distinct().ToList();
            //year
            List<string> Year = (operands_from_file.attributes_list(1, 12, 16)).Distinct().ToList();
            //adding other attributes 
            string[] seats = { "2-SEATER", "3-SEATER", "4-Seater", "5-Seater", "6-Seater", "7-Seater", "8-Seater", "9-Seater", "10-Seater" };

            // adding to list, replacing all spaces 
            foreach (string element in Color)
            {
                attributeSets.Add(element.ToUpper().Replace(" ", ""), new HashSet<string>());
            }
            foreach (string element in Model)
            {
                attributeSets.Add(element.ToUpper().Replace(" ", ""), new HashSet<string>());
            }
            foreach (string element in Make)
            {
                attributeSets.Add(element.ToUpper().Replace(" ", ""), new HashSet<string>());
            }
            foreach (string element in Grade)
            {
                attributeSets.Add(element.ToUpper().Replace(" ", ""), new HashSet<string>());
            }
            foreach (string element in seats)
            {
                attributeSets.Add(element.ToUpper().Replace(" ", ""), new HashSet<string>());
            }
            foreach (string element in Fuel)
            {
                attributeSets.Add(element.ToUpper().Replace(" ", ""), new HashSet<string>());
            }
            foreach (string element in Transmission)
            {
                attributeSets.Add(element.ToUpper().Replace(" ", ""), new HashSet<string>());
            }
            foreach (string element in Year)
            {
                attributeSets.Add(element.ToUpper().Replace(" ", "") + "-YEAR", new HashSet<string>());
            }
            foreach (string element in Sunroof) // replace true/false as required 
            {
                if (element.ToUpper() == "TRUE")
                {
                    attributeSets.Add("SUNROOF".ToUpper(), new HashSet<string>());
                }
                if (element.ToUpper() == "FALSE")
                {
                    attributeSets.Add("NOSUNROOF".ToUpper(), new HashSet<string>());
                }
            }
            foreach (string element in GPS)
            {
                if (element.ToUpper() == "TRUE")
                {
                    attributeSets.Add("GPS".ToUpper(), new HashSet<string>());
                }
                if (element.ToUpper() == "FALSE")
                {
                    attributeSets.Add("NOGPS".ToUpper(), new HashSet<string>());
                }
            }
        }

        // method to insert a vehicle to be searched 
        public void insertVehicle(string vehicleCSV)
        {
            int idx;// getiing index of matched search
            HashSet<string> hs;

            MRRCMANAGMEMENT.Vehicle v1 = new MRRCMANAGMEMENT.Vehicle(vehicleCSV);
            vehicles.Add(v1); // add vehicle from file
            // if grade mathces 
            idx = attributeSets.IndexOfKey(v1.grade_search.ToUpper());
            if (idx >= 0)
            {
                hs = (HashSet<string>)attributeSets.GetByIndex(idx); // get set
                hs.Add(v1.Reg); // add to set
                attributeSets.SetByIndex(idx, hs);  // save set (replaces old set)
            }
            idx = attributeSets.IndexOfKey(v1.make_search.ToUpper());
            if (idx >= 0)
            {   //  if Make set found
                hs = (HashSet<string>)attributeSets.GetByIndex(idx); // get set
                hs.Add(v1.Reg);// add to set
                attributeSets.SetByIndex(idx, hs);  // save set (replaces old set)
            }
            idx = attributeSets.IndexOfKey(v1.model_search.ToUpper());
            if (idx >= 0)
            {   //  if model set found
                hs = (HashSet<string>)attributeSets.GetByIndex(idx); // get set
                hs.Add(v1.Reg);// add to set
                attributeSets.SetByIndex(idx, hs);  // save set (replaces old set)
            }
            idx = attributeSets.IndexOfKey(v1.year_search);
            if (idx >= 0)
            {   //  if year set found
                hs = (HashSet<string>)attributeSets.GetByIndex(idx); // get set
                hs.Add(v1.Reg);// add to set
                attributeSets.SetByIndex(idx, hs);  // save set (replaces old set)
            }
            idx = attributeSets.IndexOfKey(v1.transmission_search.ToUpper());
            if (idx >= 0)
            {   //  if  transmission set found
                hs = (HashSet<string>)attributeSets.GetByIndex(idx); // get set
                hs.Add(v1.Reg);// add to set
                attributeSets.SetByIndex(idx, hs);  // save set (replaces old set)
            }
            idx = attributeSets.IndexOfKey(v1.fuel_search.ToUpper());
            if (idx >= 0)
            {   //  if fuel set found
                hs = (HashSet<string>)attributeSets.GetByIndex(idx); // get set
                hs.Add(v1.Reg);// add to set
                attributeSets.SetByIndex(idx, hs);  // save set (replaces old set)
            }
            idx = attributeSets.IndexOfKey(v1.Seats_search.ToUpper());
            if (idx >= 0)
            {   //  if seats set found
                hs = (HashSet<string>)attributeSets.GetByIndex(idx); // get set
                hs.Add(v1.Reg);// add to set
                attributeSets.SetByIndex(idx, hs);  // save set (replaces old set)
            }
            idx = attributeSets.IndexOfKey(v1.GPS_search.ToUpper());
            if (idx >= 0)
            {   //  if gps set found
                hs = (HashSet<string>)attributeSets.GetByIndex(idx); // get set
                hs.Add(v1.Reg);// add to set
                attributeSets.SetByIndex(idx, hs);  // save set (replaces old set)
            }
            idx = attributeSets.IndexOfKey(v1.Sunroof_search.ToUpper());
            if (idx >= 0)
            {   //  if sunrof set found
                hs = (HashSet<string>)attributeSets.GetByIndex(idx); // get set
                hs.Add(v1.Reg);// add to set
                attributeSets.SetByIndex(idx, hs);  // save set (replaces old set)
            }
            idx = attributeSets.IndexOfKey(v1.color_search.ToUpper());
            if (idx >= 0)
            {   //  if color set found
                hs = (HashSet<string>)attributeSets.GetByIndex(idx); // get set
                hs.Add(v1.Reg);// add to set
                attributeSets.SetByIndex(idx, hs);  // save set (replaces old set)
            }
        }
        public void displayVehicle(int idx)
        {
            // DISPLAY 
            MRRCMANAGMEMENT.Vehicle v1 = (MRRCMANAGMEMENT.Vehicle)vehicles[idx];
            WriteLine(v1.ToString());
        }
        public void displayVehicle(string rego)
        {   // display vehicle by registration plate (rego)

            File_Manipulation rented = new File_Manipulation();
            List<string> already_rented = rented.attributes_list(3, attributes_num_rental, attributes_num_rental);

            for (int i = 0; i < vehicles.Count; i++)
            {   // go through, find the vehicle by rego
                MRRCMANAGMEMENT.Vehicle v1 = (MRRCMANAGMEMENT.Vehicle)vehicles[i];
                if (v1.Reg == rego)
                {
                    if (!already_rented.Contains(v1.Reg))//getting rid of rented vehicles 
                    {
                        displayVehicle(i);
                        break;

                    }

                }
            }
        }

        // Serach the database, using stacks 
        public void search(out string[] result, RPN rpn)
        {
            // Create and instantiate a new empty Stack for result sets.
            Stack setStack = new Stack();
            HashSet<string> hash_set1;
            HashSet<string> hash_set2;
            HashSet<string> hash_set;
            int idx;
            String[] temp = new string[] { };
            for (int i = 0; i < rpn.Postfix.Count; i++)
            {
                if (rpn.Postfix[i].Equals("AND"))
                {
                    // pop two sets off the stack and apply Intersect, push back result
                    hash_set1 = (HashSet<string>)setStack.Pop();
                    hash_set2 = (HashSet<string>)setStack.Pop();
                    temp = hash_set1.ToArray<string>(); // copy the elements of the set hash_set1
                    hash_set = new HashSet<string>(temp); // make a deep copy of hash_set1
                    hash_set.IntersectWith(hash_set2);// apply the Intersect to the new set
                    setStack.Push(hash_set); // push a reference to a new set
                }
                else if (rpn.Postfix[i].Equals("OR"))
                {
                    // pop two sets off the stack and apply Union
                    hash_set1 = (HashSet<string>)setStack.Pop();
                    hash_set2 = (HashSet<string>)setStack.Pop();
                    temp = hash_set1.ToArray<string>(); // copy the elements of the set hash_set1
                    hash_set = new HashSet<string>(temp); // make a deep copy of hash_set1
                    hash_set.UnionWith(hash_set2); // apply the Union to the new set
                    setStack.Push(hash_set); // push a reference to a new set
                }
                else
                {
                    //  if an operand
                    idx = attributeSets.IndexOfKey(rpn.Postfix[i]); // identify attribute set
                    if (idx >= 0)
                    {
                        hash_set1 = (HashSet<string>)attributeSets.GetByIndex(idx);
                        setStack.Push(hash_set1); // note: pushing a reference, not the actual set
                    }
                    else
                    {
                        throw new FormatException("Invalid attribute" + rpn.Postfix[i]);
                    }
                }
            }
            if (setStack.Count == 1)// if only one element left 
            {
                hash_set1 = (HashSet<string>)setStack.Pop();
                result = hash_set1.ToList().ToArray();
            }
            else
            {
                throw new Exception("Invalid query");
            }
        }

        // Display the set
        void DisplaySet(HashSet<string> collection)
        {   // for displaying the contents of a set (for debugging purposes)
            Console.Write("{");
            foreach (string i in collection)
            {
                Console.Write(" {0}", i);
            }
            Console.WriteLine(" }");
        }
    } //end set_vehicles_attributes class
}
