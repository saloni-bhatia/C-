﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCMANAGMEMENT
{/// <summary>

 ///   Class customer defines the data types of the attributes of the Customer 
 ///  int :  customer id, string : title,string:  last name , string : first name ,Gender: gender , DateTime : date of birth ,
 ///  int cust_attributes : Number of attributes the customer has . 
 ///   =============================================================================
 ///   It inherits from the Gender class
 ///   ====================================================================
 ///     The class has one constructor which sets the customer id by default. 
 /// </summary>

    class Customer : Gender
    {

        private int cust_id;
        private string title;
        private string last_name;
        private string first_name;
        private Gender_ gender;
        private DateTime dob;

        public int cust_attributes = 6;

        public int Cust_Id
        {
            get
            {
                return cust_id;
            }
            set
            {
                cust_id = value;
            }
        }
        public string Title
        {
            get
            {
                return title;
            }
            set
            {
                title = value;
            }
        }

        public string Last_Name
        {
            get
            {
                return last_name;
            }
            set
            {
                last_name = value;
            }
        }
        public string First_Name
        {
            get
            {
                return first_name;
            }
            set
            {
                first_name = value;
            }
        }
        public Gender_ Gender
        {
            get
            {
                return gender;
            }
            set
            {
                gender = value;
            }
        }
        public DateTime DOB
        {
            get
            {
                return dob;
            }
            set
            {
                dob = value;
            }
        }

        // Customer() : Constructor takes no parameters. Just sets the default customer id 
        public Customer()
        {
            File_Manipulation customers_file = new File_Manipulation();
            customers_file.ReadFile(customers_file.Path[2]); // Reads the file 
            if (customers_file.Proceed == false)
            {
                customers_file.Proceed = true;
                customers_file.ReadFile(customers_file.Path[2]);
            }

            string id_;

            if (customers_file.Read_file.Count <= 1 | customers_file.Read_file.Count == 5) // if the file is empty or has no customer 
            {
                cust_id = 0;
            }

            else
            {
                id_ = customers_file.Read_file[0]; // setting a string value = the first value of the file 

                /// Setting default customer Id

                for (int i = 0; i < customers_file.Read_file.Count; i += cust_attributes) // reading the ids
                {
                    id_ = customers_file.Read_file[i];
                }
                cust_id = (Int32.Parse(id_) + 1); // Adding 1 to the last id 

            }
            this.Cust_Id = cust_id;


        }


    }
}


