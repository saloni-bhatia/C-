﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace MRRCMANAGMEMENT
{/// <summary>
/// 
/// The Fleet_Management class helps creates,modify,delete or display vehicles 
/// It inherits from the Types_specification class to make sure the fuel types, transmission types and car grades have valid inputs 
/// ==================================================================================================================================
/// 
/// The classhas 4 methods : 
/// 1) Create_Vehicle() : Creates a vehicle and return a bool . True : If the vehicle is created , False : If the creation was unsuccessful 
/// 2) Modify_Vehicle() : Modifies a vehicle and returns a bool. True : If the vehicle is modified , False : If the modification was unsuccessful
/// 3) Delete_Vehicle() : Deletes a vehicle and reeturns a bool . True : If the vehicle is deleted, False : If the deletion was unsuccessful 
/// 4) Display_Vehicle() : Displays the vehicles in the file 
/// 
/// ======================================================================================================================================
/// it contains a const int definfing the vehicles attributes number   used when an object of teh vehicle class is not created and the usage of 
/// the number of attributes is required. 
/// </summary>
/// 

    class Fleet_Management : Types_specification
    {
        const int attributes_num_vehicle = 12;

        // -----------------------------------------------    CREATE VEHICLE  -----------------------------------------//

        // The method reads the fleet file using the File_Manipulation() class asks for the inputs, 
        // checks if the inputs were correct , displays appropriate errors if any 
        // Writes to the file , if the inputs are correct and returns a bool. 
        public bool Create_Vehicle()
        {

            File_Manipulation vehicles_file = new File_Manipulation();
            bool create = true;
            vehicles_file.ReadFile(vehicles_file.Path[1]);

            int length_ = vehicles_file.Read_file.Count(); // Making an int defining the total length of the file. 
            if (vehicles_file.Proceed == true)
            {
                Console.Write("\n\n    ||ADD VEHICLE||  \n\n");

                Console.Write("+++ ENTER THE FOLLOWING DETAILS +++ \n\n " +
                "The fields marked * are mandatory \n\n Press enter after entering every input" +
                " and just press enter without any input for defaults . \n\n  1) Registration number* : ");
  
                string reg = Console.ReadLine().ToUpper();
                bool reg_ = Int32.TryParse(reg, out int reg_int);// Checking if the the reg entered is an integer
                Console.Write("\n 2) Grade* ( 0 : Economy; 1: Commercial; 2: Luxury; 3: Family) : ");
                string grade = Console.ReadLine();
                bool grade_ = Int32.TryParse(grade, out int grade_int);// Checking if the grade entered is an integer 
                Console.Write("\n 3) Make* : ");
                string make = Console.ReadLine();
                bool make_ = Int32.TryParse(make, out int make_int);// Checking if the make entered is an integer 
                Console.Write("\n 4) Model* : ");
                string model = Console.ReadLine();
                int model_int;
                bool model_ = Int32.TryParse(model, out model_int); // Checking if the model entered is an int 
                Console.Write("\n 5) Year* : ");
                string year = Console.ReadLine();
                int year_int;
                bool year_ = Int32.TryParse(year, out year_int); // Checking if the year entered is an int 
                Console.Write("\n 6) Number of seat ( betweeen 2 and 10 )  {default -- 4} : ");
                string seat = Console.ReadLine();
                int seat_int;
                bool seat_ = Int32.TryParse(seat, out seat_int); //Checking if the seat entered is an int 
                Console.Write("\n 7) Transmission (0 : Mannual ; 1: Automatic)  {Default - Mannual} : ");
                string transmission = Console.ReadLine();
                int trans_int;
                bool transmission_ = Int32.TryParse(transmission, out trans_int); // Checking if the transmission entered in an int 
                Console.Write("\n 8) Fuel_Type (0 : Petrol  ; 1: Diesel)  {Default - Petrol} :");
                string fuel = Console.ReadLine();
                int fuel_int; ;
                bool fuel_ = Int32.TryParse(fuel, out fuel_int); // Checking if the fuel_type entered is an int 
                 Console.Write("\n 9) GPS (False: Not included ; True: included) {default -- False:  Not included} :  ");
                string gps = Console.ReadLine();
                bool gps_bool;
                bool gps_ = bool.TryParse(gps, out gps_bool); // Checking if the input for gps entered is a bbol or not 
                Console.Write("\n 10) Sunroof (Fale:  Not included ; True: included) {default -- FALSE : Not included} : ");
                string sunroof = Console.ReadLine();
                bool sun_bool;
                bool sun_ = bool.TryParse(sunroof, out sun_bool);// Checking is the input for sunroof is a bool or not 
               Console.Write("\n 11) Daily Rate : ");
                string rate = Console.ReadLine();
                double rate_int;
                bool rate_ = double.TryParse(rate, out rate_int); // Checking if the input for rate is a double or not 
                Console.Write("\n 12) Color {default -- Black} : ");
                string color = Console.ReadLine();
                int color_int;
                bool color_ = Int32.TryParse(color, out color_int); // Checking if the color entered is an int or not 
                Console.Write("\n \n ------------------------------------------- \n\n ");
                Fuel_Type fuel_enum = (Fuel_Type)Convert.ToInt32(fuel_int); // Converting the fuel_int into fuel_type from Fuel_type class
                Vehicle_Grade grade_enum = (Vehicle_Grade)Convert.ToInt32(grade_int); // Converting the grade_int into Vehicle_Grade from Vehicle_Grade class 
                Transmission_Type trans_enum = (Transmission_Type)Convert.ToInt32(trans_int);// Converting the trans_int into Transmission type 
                                                                                             //  from the Type_specification class 
              ///// Checking if the mandatory fields are filled or not ////// 

                if (reg == "" | grade == "" | make == "" | model == "" | year == "")
                {
                    create = false; // Setting the bool create to false if any of the mandatory fieds are not filled 

                    Console.WriteLine("\n Fields marked * are mandatory \n");

                    if (reg == "")
                    {
                        Console.WriteLine("\n ERROR : No registration number given. ");
                    }
                    if (grade == "")
                    {
                        Console.WriteLine("\n ERROR : No grade given. ");
                    }
                    if (make == "")
                    {
                        Console.WriteLine("\n ERROR : No make given. ");
                    }
                    if (model == "")
                    {
                        Console.WriteLine("\n ERROR : No model given. ");
                    }
                    if (year == "")
                    {
                        Console.WriteLine("\n ERROR : No year given. ");
                    }
                }

                // checks the format of the registration number given 
                //As set in properties for registration this checks for correct format

                Vehicle v1 = new Vehicle(reg.ToUpper(), grade_enum, make, model, year_int);

                if (v1.Create_ == false) // Setttig the create boolean to false if v1.Create_ is set to false (i.e reg no is not in the correct form) 
                {
                    create = false;

                }


                if (create == true) // proceed only if the registration number is correct
                {

                    // Checks if the car grade is one of the valid grades 

                    if (grade_enum != Vehicle_Grade.Commercial & grade_enum != Vehicle_Grade.Economy & grade_enum != Vehicle_Grade.Family & grade_enum != Vehicle_Grade.Luxury)

                    {
                        create = false; //set to false , if the car grade is not valid 

                        Console.WriteLine($"\n ERROR : The given {grade_enum} is not a valid grade");
                    }

                    // Checks if the Transmission type  is one of the valid types

                    if (trans_enum != Transmission_Type.Automatic & trans_enum != Transmission_Type.Mannual)
                    {
                        create = false;

                        Console.WriteLine($"\n ERROR : The given {trans_enum} is not a valid transmssion type");
                    }

                    // Checks if the fuel type  is one of the valid types

                    if (fuel_enum != Fuel_Type.Diesel & fuel_enum != Fuel_Type.Petrol)
                    {
                        create = false;

                        Console.WriteLine($"\n ERROR : The given {fuel_enum} is not a valid fuel type");
                    }
                }


                // Checking for valid inputs //

                // If grade_,year_,fuel_,rate_ are not numeric
                // model_,make_,year_,transmission_,color_ are integers 
                // gps_, sun_  are not boolean 

                if (create == true)
                {
                    if (!grade_ | model_ | make_ | !year_ | !transmission_ | !gps_ | !sun_ | color_ | !seat_ | !fuel_ | !rate_)
                    {

                        if (!grade_)
                        {
                            create = false;
                            Console.WriteLine($"\n ERROR : The given grade {grade} is not valid.( 0: Economy;  1: Commercial;   2:Luxury;  3:Family) ");
                        }

                        if (model_)
                        {
                            create = false;
                            Console.WriteLine($"\n ERROR : The given model {model} is not valid. ");
                        }
                        if (make_)
                        {
                            create = false;
                            Console.WriteLine($"\n ERROR : The given make {make} is not valid. ");
                        }


                        if (!year_)
                        {
                            create = false;
                            Console.WriteLine($"\n ERROR : The given year {year} is not valid. ");

                        }


                        if (!transmission_)
                        {

                            if (transmission == "")
                            {  // Setting default if no transmission type was given 
                                if (grade_enum == Vehicle_Grade.Economy)
                                {
                                    trans_enum = Transmission_Type.Automatic;
                                }

                                else
                                {
                                    trans_enum = Transmission_Type.Mannual;


                                }
                                if (create != false)
                                {
                                    Console.WriteLine($"\n DEFAULT SET  : Transmission set to {trans_enum} by default. ");

                                }
                            }
                            else
                            {
                                create = false;
                                Console.WriteLine($"\n ERROR :The given transmission {transmission} is not valid. (0 : Mannual ; 1: Automatic)  [ Default - Mannual] ");
                            }

                        }

                        if (!gps_)
                        {

                            // Setting default if there was no gps was given 

                            if (gps == "")

                            {
                                if (grade_enum == Vehicle_Grade.Luxury)
                                {
                                    gps_bool = true;

                                }
                                else
                                {
                                    gps_bool = false;
                                }
                                if (create != false)
                                {
                                    Console.WriteLine($"\n DEFAULT SET  : GPS  set to {gps_bool} by default. ");

                                }

                            }
                            else
                            {
                                create = false;
                                Console.WriteLine($"\n ERROR : The given gps option  {gps} is not valid.  (Fale:  Not included ; True: included) [default-- FALSE : Not included] ");

                            }
                        }

                        if (!sun_)
                        {
                            // Setting defaults if no sunroof input was given 

                            if (sunroof == "")

                            {

                                if (grade_enum == Vehicle_Grade.Luxury)
                                {
                                    sun_bool = true;

                                }
                                else
                                {
                                    sun_bool = false;
                                }
                                if (create != false)
                                {
                                    Console.WriteLine($"\n DEFAULT SET  : sunroof  set to {sun_bool} by default. ");
                                }

                            }

                            else
                            {
                                create = false;
                                Console.WriteLine($"\n ERROR : The given sunroof option  {sunroof} is not valid.  (Fale:  Not included ; True: included) [default-- FALSE : Not included] ");
                            }
                        }

                        if (color_)
                        {

                            create = false;
                            Console.WriteLine($"\n ERROR : The given color {color} is not valid. ");

                        }
                        // Setting defaults if no input for number of seats is given 

                        if (!seat_)
                        {

                            if (seat == "")

                            {

                                seat_int = 4;
                                if (create != false)
                                {
                                    Console.WriteLine("\n DEFAULT SET : Number of  seats to 4 by default.");
                                }


                            }
                            else
                            {

                                create = false;
                                Console.WriteLine($"\n ERROR : The given number of seats {seat} is not valid. ");
                            }

                        }
                        // Setting the fuel types if there are no inputs given
                        if (!fuel_)
                        {
                            if (fuel == "")

                            {

                                if (grade_enum == Vehicle_Grade.Commercial)
                                {
                                    fuel_enum = Fuel_Type.Diesel;
                                    if (create != false)
                                    {
                                        Console.Write($"\n DEFAULT SET : Fuel type set to {fuel_enum} by default");
                                    }

                                }
                            }

                            else
                            {
                                create = false;
                                Console.WriteLine($"\n ERROR : The given fuel type {fuel} is not valid. (0 : Mannual ; 1: Automatic)  [Default - Petrol]  ");
                            }

                        }


                        // Setting defaults if rate input is not given 
                        if (!rate_)
                        {

                            if (rate == "")
                            {
                                if (grade_enum == Vehicle_Grade.Economy)
                                {
                                    rate_int = 50;

                                }
                                else if (grade_enum == Vehicle_Grade.Luxury)
                                {
                                    rate_int = 120;
                                }
                                else if (grade_enum == Vehicle_Grade.Family)
                                {
                                    rate_int = 80;
                                }
                                else if (grade_enum == Vehicle_Grade.Commercial)
                                {
                                    rate_int = 130;

                                }
                                else
                                {
                                    rate_int = 50;
                                }
                                if (create != false)
                                {
                                    Console.WriteLine($" \n DEFAULT SET : Hire rate set to $ {rate_int} by default.");

                                }

                            }
                            else
                            {
                                create = false;
                                Console.WriteLine($"\n ERROR : The given daily hire rate {rate}  is not valid.  ");
                            }

                        }

                    }
                }


                // using the properties of the Vehicle class (v1 object) to check the negative values 
                if (create == true)
                {
                    v1.Seats = seat_int;
                    v1.Daily_rate = rate_int;
                    v1.Year = year_int;

                }

                // Making the boolean false if the v1 object sets the Create_ as false
                if (v1.Create_ == false)
                {
                    create = false;

                }



                if (length_ > 0) // The length of the file > 0 
                {
                    // Going through the file till the reg number given  is found ; making sure it is UNIQUE

                    for (int reg_id = 0; reg_id < length_ - 1; reg_id += v1.vehicle_attributes)
                    {

                        if (vehicles_file.Read_file[reg_id] != reg.ToUpper())
                        {

                            reg = reg.ToUpper();
                        }

                        else
                        {
                            create = false;

                            Console.WriteLine($"\n ERROR : The Registration number {reg} already exists");
                            break;
                        }

                    }
                }

                if (create == true)
                {
                    v1.Colour = color;
                    // Making an array with attributes of the vehicle class 

                    string[] attributes = { reg.ToUpper(), grade_enum.ToString(), make, model, year.ToString(), v1.Seats.ToString(), trans_enum.ToString(), fuel_enum.ToString(), gps_bool.ToString().ToUpper(), sun_bool.ToString().ToUpper(), v1.Daily_rate.ToString(), v1.Colour };


                    // Write only if all the inputs are valid and reg no is unique. 


                    List<String> a = new List<String>();

                    a = vehicles_file.Csv_File(attributes, v1.vehicle_attributes); // making a comma separated file 


                    if (length_ <= 1)
                    {
                        // write as a new file  into the file  if there is no data in the file 

                        vehicles_file.WriteFile_New(vehicles_file.Path[1], a);
                    }


                    else // if there is some  data write append
                    {
                        vehicles_file.WriteFile(vehicles_file.Path[1], a);

                    }

                    Console.WriteLine("\n The vehicle was added !\n");

                    vehicles_file.Table(3 * (attributes.Length)); // Displaying the new vehicle's attributes 

                    Console.WriteLine();

                    Console.Write(" ");


                    for (int i = 0; i < attributes.Length; i++)
                    {
                        Console.Write(attributes[i] + "    ");


                    }

                    Console.WriteLine();
                    vehicles_file.Table(3 * (attributes.Length));
                    Console.WriteLine();




                }//create == true

            }//file exists
            else
            {
                Console.WriteLine($"\n The FILE at {vehicles_file.Path[1]} does not exist");
                create = false;
            }


            return create;

        }// end Create_Vehicle()


        // -----------------------------------------------    MODIFY VEHICLE  -----------------------------------------//




        // The method reads the fleet file using the File_Manipulation() class asks for the inputs,
        // checks if the inputs were correct , displays appropriate errors if any 
        // Writes to the file , if the inputs are correct and returns a bool. 

        public bool Modify_Vehicle()

        {
            bool modify = false;// bool defining success 

            bool id_found = false; // bool to find the id 

            File_Manipulation vehicles_file = new File_Manipulation();

            vehicles_file.ReadFile(vehicles_file.Path[1]); // reading the file 
            if (vehicles_file.Proceed == false)
            {
                vehicles_file.Proceed = true;
                vehicles_file.ReadFile(vehicles_file.Path[1]);

            }


            if (vehicles_file.Proceed == true) // ony proceed if there is a vehilcles file existing 
            {
                int length_ = vehicles_file.Read_file.Count;

                if (vehicles_file.Proceed == true)
                {

                    Console.Write("\n\n   ||MODIFY VEHICLE||   \n\n Enter the Registration number for the vehicle to be modified  : ");

                    string reg = Console.ReadLine();
                    int reg_int;
                    bool reg_bool = Int32.TryParse(reg, out reg_int);

                    if (reg_bool) // making if the registration number is just an int
                    {
                        modify = false;
                        Console.WriteLine($"\n ERROR : Invalid Registration number {reg}");

                    }
                    else
                    {
                        if (length_ <= 1)
                        {
                            Console.WriteLine("There are no vehicles in the database \n");
                            modify = false;
                        }
                        else
                        {

                            for (int reg_ids = 0; reg_ids < length_ - 1;) // Going through the file to find the entered reg_number 
                            {

                                if (vehicles_file.Read_file[reg_ids] == reg.ToUpper())
                                {

                                    id_found = true;
                                    modify = true;

                                    Console.WriteLine($"\n The Registration number {reg} found"); // if reg no is found 
                                    int end = reg_ids + attributes_num_vehicle; // setting the end of the loop with the number of vehicle attributes (12)
                                    vehicles_file.Table(4 * attributes_num_vehicle);// Displaying the attributes 
                                    Console.WriteLine();

                                    // making an array to store the original attributes of the vehicle to be modified . 

                                    string[] data_old = new string[attributes_num_vehicle];
                                    int i = 0;
                                    for (; reg_ids < end; reg_ids++)
                                    {
                                        data_old[i] = vehicles_file.Read_file[reg_ids];
                                        Console.Write(vehicles_file.Read_file[reg_ids] + "  ");
                                        i++;
                                    }

                                    Console.WriteLine();
                                    vehicles_file.Table(4 * attributes_num_vehicle);
                                    reg_ids -= attributes_num_vehicle;

                                    if (modify == true)

                                    {
                                        // Asking for inputs  following the same rules as Create_Vehicle() to make sure for valid inputs// 

                                        Console.WriteLine("\n Type the attributes you want to modify , leave the space blank for the attributes not being modified.\n");

                                        Console.Write("1) Registration Number : ");
                                        string reg_id_m = Console.ReadLine();
                                        int reg_m;
                                        bool reg_modify = Int32.TryParse(reg_id_m, out reg_m);

                                        Console.Write("2) Grade ( 0 : Economy; 1: Commercial; 2: Luxury; 3: Family) : ");
                                        string grade = Console.ReadLine();
                                        int grade_int;
                                        bool grade_m = Int32.TryParse(grade, out grade_int);

                                        Console.Write("3) Make : ");
                                        string make = Console.ReadLine();
                                        int make_;
                                        bool make_m = Int32.TryParse(make, out make_);

                                        Console.Write("4) Model : ");
                                        string model = Console.ReadLine();
                                        int model_;
                                        bool model_m = Int32.TryParse(model, out model_);

                                        Console.Write("5) Year : ");
                                        string year = Console.ReadLine();
                                        int year_;
                                        bool year_m = Int32.TryParse(year, out year_);

                                        Console.Write("6) No of seats (Number between 2 and 10 )  : ");
                                        string seats = Console.ReadLine();
                                        int seats_;
                                        bool seats_m = Int32.TryParse(seats, out seats_);

                                        Console.Write("7) Transmission (0: Mannual ; 1: Automatic) : ");
                                        string transmission = Console.ReadLine();
                                        int trans_int;
                                        bool trans_m = Int32.TryParse(transmission, out trans_int);

                                        Console.Write("8) Fuel (0: Petrol ; 1: Diesel) :  ");
                                        string fuel = Console.ReadLine();
                                        int fuel_int;
                                        bool fuel_m = Int32.TryParse(fuel, out fuel_int);

                                        Console.Write("9) GPS  (False : No , True : Yes ) : ");
                                        string gps = Console.ReadLine();
                                        bool gps_;
                                        bool gps_m = bool.TryParse(gps, out gps_);

                                        Console.Write("10) Sunroof (False : No , True : Yes )  : ");
                                        string sunroof_ = Console.ReadLine();
                                        bool sun_;
                                        bool sun_m = bool.TryParse(sunroof_, out sun_);

                                        Console.Write("11) Hire Rate  : ");
                                        string hire = Console.ReadLine();
                                        double hire_;
                                        bool hire_m = double.TryParse(hire, out hire_);

                                        Console.Write("12) Color  : ");
                                        string color = Console.ReadLine();
                                        int color_;
                                        bool color_m = Int32.TryParse(color, out color_);


                                        Fuel_Type fuel_enum = (Fuel_Type)Convert.ToInt32(fuel_int);  // Converting the fuel_int into fuel_type 

                                        Vehicle_Grade grade_enum = (Vehicle_Grade)Convert.ToInt32(grade_int);  // Converting the grade_int into Car_grade


                                        // converting the trans_int into Transmission_Type
                                        Transmission_Type trans_enum = (Transmission_Type)Convert.ToInt32(trans_int);


                                        // Setting the attributes as the old ones if no input is given 
                                        if (reg_id_m == "" | grade == "" | make == "" | model == "" | year == "" | seats == "" | transmission == "" | fuel == "" | gps == "" | sunroof_ == "" | hire == "" | color == "")


                                        {

                                            if (reg_id_m == "")
                                            {

                                                reg_id_m = data_old[0];
                                            }


                                            if (grade == "")
                                            {

                                                grade = data_old[1];
                                            }

                                            if (make == "")
                                            {

                                                make = data_old[2];

                                            }

                                            if (model == "")
                                            {

                                                model = data_old[3];
                                            }

                                            if (year == "")
                                            {

                                                year = data_old[4];
                                            }

                                            if (seats == "")
                                            {

                                                seats = data_old[5];
                                            }

                                            if (transmission == "")
                                            {
                                                transmission = data_old[6];
                                            }

                                            if (fuel == "")
                                            {
                                                fuel = data_old[7];
                                            }

                                            if (gps == "")
                                            {
                                                gps = data_old[8];
                                            }

                                            if (sunroof_ == "")
                                            {
                                                sunroof_ = data_old[9];
                                            }

                                            if (hire == "")
                                            {
                                                hire = data_old[10];
                                            }

                                            if (color == "")
                                            {
                                                color = data_old[11];
                                            }


                                        }
                                        // To check if the the given inputs are of the correct data type, given they are not the old values  

                                        if (reg_modify | !grade_m | make_m | model_m | !year_m | !seats_m | !trans_m | !fuel_m | !gps_m | !sun_m | !hire_m | color_m)
                                        {


                                            if (reg_modify & reg_id_m != data_old[0])
                                            {
                                                modify = false;
                                                Console.WriteLine($"\n\n The registration no {reg} is Invalid");

                                            }

                                            if (!grade_m & grade != data_old[1])
                                            {
                                                modify = false;
                                                Console.WriteLine($"\n\n The grade {grade} is Invalid");

                                            }

                                            if (make_m & make != data_old[2])
                                            {
                                                modify = false;
                                                Console.WriteLine($"\n\n The make {make} is Invalid");

                                            }

                                            if (model_m & model != data_old[3])
                                            {
                                                modify = false;
                                                Console.WriteLine($"\n\n The model {model} is Invalid");

                                            }

                                            if (!year_m & year != data_old[4])
                                            {
                                                modify = false;
                                                Console.WriteLine($"\n\n The year {year} is Invalid");

                                            }

                                            if (!seats_m & seats != data_old[5])
                                            {
                                                modify = false;
                                                Console.WriteLine($"\n\n The no of seats {seats} is Invalid");

                                            }

                                            if (!trans_m & transmission != data_old[6])
                                            {
                                                modify = false;
                                                Console.WriteLine($"\n\n The transmission type {transmission} is Invalid");

                                            }

                                            if (!fuel_m & fuel != data_old[7])
                                            {
                                                modify = false;
                                                Console.WriteLine($"\n\n The fuel type {fuel} is Invalid");

                                            }

                                            if (!gps_m & gps != data_old[8])
                                            {
                                                modify = false;
                                                Console.WriteLine($"\n\n The gps option {gps} is Invalid");

                                            }

                                            if (!sun_m & sunroof_ != data_old[9])
                                            {
                                                modify = false;
                                                Console.WriteLine($"\n\n The sunroof option {sunroof_} is Invalid");

                                            }

                                            if (!hire_m & hire != data_old[10])
                                            {
                                                modify = false;
                                                Console.WriteLine($"\n\n The daily hire rate {hire} is Invalid"); 

                                            }

                                            if (color_m & color != data_old[11])
                                            {
                                                modify = false;
                                                Console.WriteLine($"\n\n The color {color} is Invalid");


                                            }

                                        }

                                        if (modify == true) // if the inputs are valid
                                        {
                                            if (reg_id_m != data_old[0])/// if the given reg number is not the same check for uniqueness 
                                            {
                                                for (int r_id = 0; r_id < length_ - 1; r_id += attributes_num_vehicle)
                                                {

                                                    if (vehicles_file.Read_file[r_id] == reg_id_m.ToUpper())
                                                    {
                                                        if (reg_id_m.ToUpper() != data_old[0])
                                                        {
                                                            modify = false;

                                                            Console.WriteLine($"\n The Registration {reg_id_m.ToUpper()} already exists !");
                                                            break;
                                                        }
                                                        else if (reg_id_m.ToUpper() != data_old[0])
                                                        {
                                                            modify = true;
                                                            break;
                                                        }

                                                    }
                                                }

                                            }

                                            Vehicle v1 = new Vehicle(reg_id_m, grade_enum, make, model, year_);

                                            // Checking if the grade is valid if new  grade is given ( assuming the old grade is valid) 

                                            if (grade != data_old[1])
                                            {
                                                if (grade_enum == Vehicle_Grade.Commercial | grade_enum == Vehicle_Grade.Economy | grade_enum == Vehicle_Grade.Family | grade_enum == Vehicle_Grade.Luxury)
                                                {
                                                    modify = true;

                                                }
                                                else
                                                {
                                                    Console.WriteLine($"\n\n Invalid grade  {grade}");
                                                    modify = false;
                                                }
                                            }

                                            // Checking if the transmission is valid if new transmission is given ( assuming the old type is valid) 

                                            if (transmission != data_old[6])
                                            {

                                                if (trans_enum != Transmission_Type.Automatic & trans_enum != Transmission_Type.Mannual)
                                                {

                                                    modify = false;
                                                    Console.WriteLine($"\n\n Invalid transmission type {transmission} \n");
                                                }
                                            }

                                            // Checking if the fuel type  is valid if new fuel type  is given ( assuming the old type is valid) 

                                            if (fuel != data_old[7])
                                            {
                                                if (fuel_enum != Fuel_Type.Diesel & fuel_enum != Fuel_Type.Petrol)
                                                {
                                                    Console.WriteLine($"\n\n Invalid fuel type {fuel_enum}");
                                                    modify = false;


                                                }

                                            }

                                            if (hire != data_old[10])
                                            {
                                                v1.Daily_rate = hire_;// checking for neg values 


                                            }

                                            if (seats != data_old[5])
                                            {

                                                v1.Seats = seats_;// checking for neg value 


                                            }

                                            // Setting th modify bool to false if there are input error found by properties of v1 

                                            if (v1.Create_ == false)
                                            {
                                                modify = false;
                                            }
                                        }

                                        if (modify == true)
                                        {

                                            string[] attributes = { reg_id_m.ToUpper(), grade, make, model, year, seats, trans_enum.ToString(), fuel_enum.ToString(), gps_.ToString().ToUpper(), sun_.ToString().ToUpper(), hire, color };

                                            // Changing the data in the file.

                                            for (int new_ = 0; new_ < data_old.Length; new_++)
                                            {
                                                data_old[new_] = attributes[new_];
                                                vehicles_file.Read_file[reg_ids] = data_old[new_];
                                                reg_ids++;

                                            }

                                            // Writting the modified data into the file 

                                            List<String> a = new List<String>();

                                            a = vehicles_file.Csv_File(vehicles_file.Read_file.ToArray(), attributes_num_vehicle);


                                            vehicles_file.WriteFile_New(vehicles_file.Path[1], a);

                                            Console.WriteLine("\n  The vehicle was modified ! \n");

                                            // Displaying the modified values 

                                            vehicles_file.Table(3 * (attributes.Length));

                                            Console.WriteLine();


                                            Console.Write(" ");

                                            for (int att_ = 0; att_ < attributes.Length; att_++)
                                            {
                                                Console.Write(data_old[att_] + "   ");


                                            }

                                            Console.WriteLine();

                                            vehicles_file.Table(3 * (attributes.Length));

                                            Console.WriteLine();

                                        }

                                    }
                                    break;

                                }

                                else
                                {
                                    id_found = false;
                                }
                                reg_ids += attributes_num_vehicle; // updating the index by the number of attributes of the vehicle 

                            }
                        }
                        if (id_found == false)
                        {
                            Console.WriteLine($" Registration number {reg} not found!");
                        }



                    }//end else

                }//end proceed == true

                else
                {
                    modify = false;
                    Console.WriteLine($"\n The FILE at {vehicles_file.Path[1]} does not exist.");
                }

            }// end of if (proceed== true)

            else
            {
                modify = false;
                Console.WriteLine($"The FILE at {vehicles_file.Path} does not exist.");
            }

            return modify;

        }//End Modify_Vehicle()

        // -----------------------------------------------    DELETE VEHICLE  -----------------------------------------//




        // The method reads the fleet file using the File_Manipulation() class asks for the inputs,
        // checks if the inputs were correct , displays appropriate errors if any 
        // Writes to the file ,  returns a bool.



        public bool Delete_Vehicle()
        {
            File_Manipulation vehicles_file = new File_Manipulation();

            vehicles_file.ReadFile(vehicles_file.Path[1]);
            if (vehicles_file.Proceed == false)
            {
                vehicles_file.Proceed = true;
                vehicles_file.ReadFile(vehicles_file.Path[1]);

            }
            bool delete = true; bool id_found = true;

            if (vehicles_file.Proceed == true)// proceed only if the file exists
            {

                int length_ = vehicles_file.Read_file.Count;


                Console.WriteLine("\n\n ||DELETE VEHICLE||   \n\n");
                Console.Write("Enter the registration number of the vehicle to be deleted : ");
                string reg_id = Console.ReadLine().ToUpper();

                // Checkig if the data format is correct 
                int reg_;
                bool reg = Int32.TryParse(reg_id, out reg_);
                if (reg | reg_id == "")

                {
                    // Finding what is wrong with the registration number entered to display the correct feedback

                    while (delete != false)
                    {

                        if (reg)
                        {
                            Console.WriteLine($"\n\n The registration number {reg_id} is not in the correct format");
                            delete = false;
                            break;
                        }

                        else
                        {
                            Console.Write($"\n\n Please enter a valid registration number :");
                            reg_id = Console.ReadLine();
                            reg = Int32.TryParse(reg_id, out reg_);
                            if (!reg)
                            {
                                delete = true;
                            }



                        }


                    }
                }

                else if (length_ > 1)

                {
                    // Search if the registration no exists in the data base only if length_ > 1// 
                    // read the rental file 
                    File_Manipulation rentals = new File_Manipulation();
                    // Defining an int to go thriugh the rental file 
                    int rental_vehicle = 0;
                    // bool to make sure that the vehicle is not beig rented 
                    bool is_rented = false;
                    rentals.ReadFile(rentals.Path[3]);
                    if (rentals.Proceed == false)
                    {
                        rentals.Proceed = true;
                        rentals.ReadFile(rentals.Path[3]);

                    }
                    for (int reg_ids = 0; reg_ids < length_ - 1;)
                    {
                        if (vehicles_file.Read_file[reg_ids] == reg_id)

                        {
                            for (; rental_vehicle <= rentals.Read_file.Count() - 1;)
                            {
                                if (rentals.Read_file[rental_vehicle] != reg_id)
                                {
                                    delete = true;
                                }
                                else
                                {
                                    delete = false;
                                    is_rented = true;
                                    Console.WriteLine(" \n Cannot delete vehicle. Vehicle is being rented.");
                                }
                                rental_vehicle += 2; // updating the index for the rental file
                            }
                            if (is_rented != true)
                            {


                                id_found = true;


                                string[] data = new string[attributes_num_vehicle]; // an array of length of mo of attributes 

                                Console.WriteLine($"\n The vehicle with reg no {reg_id} was found ! \n ");

                                // Displaying the details of the vehicle be deleted  and adding it into an array for further use 

                                vehicles_file.Table(3 * attributes_num_vehicle);

                                Console.WriteLine();

                                for (int disp = 0; disp < attributes_num_vehicle; disp++)

                                {
                                    Console.Write(vehicles_file.Read_file[reg_ids] + " ");
                                    data[disp] = vehicles_file.Read_file[reg_ids];
                                    reg_ids++;
                                }

                                Console.WriteLine();

                                vehicles_file.Table(3 * attributes_num_vehicle);

                                Console.WriteLine();

                                reg_ids -= attributes_num_vehicle; // getting the reg_ids back after displaying ; 


                                // Confirming deletion 

                                Console.Write($"\n Are you sure you want to delete the vehicle {reg_id} ? (Y : YES ; N : NO)  ");

                                string confirm = Console.ReadLine();


                                // Deleting if sure 

                                if (confirm.ToUpper() == "Y")

                                {
                                    vehicles_file.Read_file.RemoveRange(reg_ids, attributes_num_vehicle); // removing all the 12 attributes of the saod vehicle

                                    // Writing  to the file 
                                    List<String> a = new List<String>();


                                    a = vehicles_file.Csv_File(vehicles_file.Read_file.ToArray(), attributes_num_vehicle);


                                    vehicles_file.WriteFile_New(vehicles_file.Path[1], a);

                                    Console.WriteLine("\n The vehicle was deleted !\n");

                                    break;

                                }


                                // not deleting the vehicle

                                else if (confirm.ToUpper() == "N")

                                {

                                    delete = false;
                                    break;

                                }


                            }
                        }
                        else

                        {
                            delete = false;

                            id_found = false;

                        }

                        reg_ids += attributes_num_vehicle; // Updating the index of the loop by the number of attributes of the vehicle 


                    }
                    if (id_found == false && is_rented != true)
                    {
                        Console.WriteLine($"Registration number {reg_id} not found !\n ");
                    }

                }

                else
                {
                    Console.WriteLine("There are no vehicles to delete \n");
                    delete = false;
                }

            }// end of if (vehicles_file.Proceed==true)

            else
            {
                delete = false;

                Console.WriteLine($"\n The FILE at {vehicles_file.Path[1]} does not exits!");
            }
            return delete;


        }//End Delete_Vehicle


        // -----------------------------------------------    DISPLAY VEHICLE  -----------------------------------------//



        // The method reads the fleet file using the File_Manipulation() class and displays them in a table 

        public void Display_Vehicle()
        {
            File_Manipulation vehicles_file = new File_Manipulation();

            // reading the file 
            vehicles_file.ReadFile(vehicles_file.Path[1]);
            if (vehicles_file.Proceed == false)
            {
                vehicles_file.Proceed = true;
                vehicles_file.ReadFile(vehicles_file.Path[1]);

            }

            if (vehicles_file.Proceed == true)
            {

                //// Forming a table 

                int var = 0; int index = 0; int l = 0;
                int len = (vehicles_file.Read_file.Count);
                if (len <= 1)
                {
                    Console.WriteLine("\n There are no vehicles stored \n");
                }
                else
                {

                    int width = ("  " + vehicles_file.Read_file[0] + "  ").Length; // initialising the width of the cell of the table

                    vehicles_file.Table(4 * width);


                    Console.WriteLine();

                    while (var < len)
                    {

                        for (; l < attributes_num_vehicle; index++)
                        {
                            if (index < len)
                            {
                                // making sure the cells are of same size

                                width = Math.Abs(vehicles_file.Read_file[index].Length - (vehicles_file.Read_file[0].Length));
                                string width_ = "";

                                //making a string that is of the size of the difference between the ideal and the present width
                                for (int i = 0; i < width; i++)
                                {
                                    width_ += " ";
                                }

                                Console.Write("  " + vehicles_file.Read_file[index] + width_ + " |");
                                l++;

                                width = ("  " + vehicles_file.Read_file[index] + width_ + " |").Length;

                            }
                            else
                            {
                                break;
                            }



                        }
                        Console.WriteLine();

                        vehicles_file.Table(4 * width);


                        l = 0;

                        var += attributes_num_vehicle;// updating the index for the loop by the number of  vehicle's attributes 


                        Console.WriteLine();

                    }
                } //end else statement

            } // end of if statement 

            else
            {
                Console.WriteLine($"The FILE at {vehicles_file.Path[1]} does not exist! \n\n Cannot display vehicles");
            }

        } //End Display_Vehicle



    } // end of class

}//End namespace


