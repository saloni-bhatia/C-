﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCMANAGMEMENT
{/// <summary>
/// 
/// This class describes the enum types for fuel types, Vehicle_Grade and transmission types. 
/// ===========================================================================================
/// The class is inherited by the Vehicle class 
/// 
/// </summary>
    public  class Types_specification
    {
        public enum Fuel_Type
        {
            Petrol,
            Diesel

        }

        public enum Vehicle_Grade
        {
            Economy,
            Commercial,
            Luxury,
            Family
        }

        public enum Transmission_Type
        {
            Mannual,
            Automatic
        }
    }
}
