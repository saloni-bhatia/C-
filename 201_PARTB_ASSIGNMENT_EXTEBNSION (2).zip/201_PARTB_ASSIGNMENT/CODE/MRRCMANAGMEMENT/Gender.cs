﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCMANAGMEMENT
{
    /// <summary>
    /// Defining a class for the Gender of customers making it easier to navigate input and add more if needed , 
    /// </summary>
    public class Gender
    {
        public enum Gender_
        {
            Male,
            Female,
            Other
        }
    }


}
