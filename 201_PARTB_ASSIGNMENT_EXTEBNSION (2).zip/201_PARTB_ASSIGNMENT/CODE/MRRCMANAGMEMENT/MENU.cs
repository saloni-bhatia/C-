﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
namespace MRRCMANAGMEMENT
{/// <summary>
 /// 
 /// The Menu_ class is made to organise the flow of the program . It has 4 variables  - 
 /// 1) home_menu : string value storing the Home menu 
 /// 2) menu1 : string value storing the fleet managememnt options
 /// 3) menu2 : string value storing the customer management options 
 /// 4) choice : Which stores the values of the users selected option
 /// ===================================================================================
 /// 
 /// The class has 3  methods
 /// 
 /// 1) Home() : prints the home_menu , asks for the option , reads the input and acts accordingly 
 /// 2) Fleet_Management() : prints menu1 , asks for the option , reads the input and acts accordingly
 /// 3) Customer_Management() : prints menu2, asks for the option, reads the input and acts accordingly
 /// =====================================================================================================
 /// 
 /// Menu_ class creates objects for Fleet_Management and CRM to access their methods.
 /// ======================================================================================
 /// 
 /// </summary>
    public class Menu_
    {
        // Defininh the string menus . 
        private string home_menu = (" 1) Fleet Management \n 2) Customer Management \n 3) Rental Management \n \n  * If you want to quit please press \'Q\' \n \n   ");
        private string menu1 = ("\n\n     || FLEET MANAGEMENT ||    \n Please enter a valid option or press 'h' to go to the Home Menu or 'Q' to Exit.  \n\n 1) Add Vehhicle \n 2) Modify Vehicle \n 3) Delete Vehicle \n 4) Display Vehicle \n\n ");
        private string menu2 = ("\n\n     || CUSTOMER MANAGEMENT ||  \n Please enter a valid option or press 'h' to go to the Home Menu or 'Q' to Exit. \n\n 1) Add Customer \n 2) Modify Customer \n 3) Delete Customer \n 4) Display Customer \n\n ");
        private string menu3 = ("\n\n     || RENTAL MANAGEMENT ||    \n Please enter a valid option or press 'h' to go to the Home Menu or 'Q' to Exit. \n\n 1) Rent Vehicle \n 2) Return Vehicle \n 3) Search Vehicle \n 4) Display Rntal Information \n\n ");
        private string choice;
        // Creating objects to access the methods
        Fleet_Management Fleet = new Fleet_Management();
        readonly CRM customer = new CRM();
        Rental_management rental = new Rental_management();
        // Home() : printing the home_menu , asking for the input and accessing the method required 
        public void Home()
        {
            Console.WriteLine(home_menu);
            choice = Console.ReadLine();
            if (choice.ToUpper() == "Q")
            {
                Environment.Exit(0); // Exit if Q is read
            }
            if (choice == "1")
            {
                Fleet_Management(); // Access the Fleet_Management()  method
            }
            else if (choice == "2")
            {
                Customer_Management(); // Access the Customer_Management() method
            }
            else if (choice == "3")
            {
                Rental_Management();
            }
            else
            {
                Console.WriteLine("\n Please Enter a valid option \n "); // Asks for a valid input 
                Home();
            }
        } // End Home() 


        /// ///////////////////////////  FLEET  Management  ///////////////////////////////////////
        public void Fleet_Management()
        {
            Console.WriteLine(menu1); // print the flet management menu 
            choice = Console.ReadLine(); // Reading the input 
            if (choice == "1")
            {
                bool create = Fleet.Create_Vehicle();  // using the create_vehicle() method of the Fleet_Management to create a vehicle . 
                if (create == true) // checking if the method created a vehicle successfully 
                {
                    Console.WriteLine("\n  Press \'H\' to go back Home or \'B\' to go back or  \'Q\' to Exit \n"); // Asking for an option to go back Home or g back or  or quiting the program
                    choice = Console.ReadLine();
                    if (choice.ToUpper() == "H")
                    {
                        Home();
                    }
                    else if (choice.ToUpper() == "Q")
                    {
                        Environment.Exit(0);
                    }
                    else if (choice.ToUpper() == "B")
                    {
                        Fleet_Management();
                    }
                    else
                    {
                        Console.WriteLine("\n Invalid Option \n \n Going back Home"); // If not a valid input going back to Home
                        Home();
                    }
                }
                else
                {
                    Console.WriteLine("\n\n   Cannot create vehicle   \n\n +++++++++ Going back ++++++++++ \n \n \n"); // If the vehicle is not created, go back to fleet management
                    Fleet_Management();
                }
            }
            else if (choice == "2")
            {
                bool modify = Fleet.Modify_Vehicle(); // Accessing the Modify_Vehicle() of the Feet_Management 
                if (modify == true) //Checking if the modification was successfull 
                {
                    Console.WriteLine("\n  Press \'H\' to go back Home or \'B\' to go back or  \'Q\' to Exit \n"); // Asking for an option to go back Home or g back or  or quiting the program
                    choice = Console.ReadLine();
                    if (choice.ToUpper() == "H")
                    {
                        Home();
                    }
                    else if (choice.ToUpper() == "Q")
                    {
                        Environment.Exit(0);
                    }
                    else if (choice.ToUpper() == "B")
                    {
                        Fleet_Management();
                    }
                    else
                    {
                        Console.WriteLine("\n Invalid Option \n \n Going back Home"); // If not a valid input going back to Home
                        Home();
                    }
                }
                else
                {
                    Console.WriteLine("\n\n  Cannot modify vehicle   \n  +++++++++ Going back ++++++++++ \n  \n \n"); // If the vehicle was not modified , go back to fleet management
                    Fleet_Management();
                }
            }
            else if (choice == "3")
            {
                bool delete = Fleet.Delete_Vehicle(); // Accessing the Delete_Vehicle() from the Fleet_Management 
                if (delete == true)
                {
                    Console.WriteLine("\n  Press \'H\' to go back Home or \'B\' to go back or  \'Q\' to Exit \n"); // Asking for an option to go back Home or g back or  or quiting the program
                    choice = Console.ReadLine();
                    if (choice.ToUpper() == "H")
                    {
                        Home();
                    }
                    else if (choice.ToUpper() == "Q")
                    {
                        Environment.Exit(0);
                    }
                    else if (choice.ToUpper() == "B")
                    {
                        Fleet_Management();
                    }
                    else
                    {
                        Console.WriteLine("\n Invalid Option \n \n Going back Home"); // If not a valid input going back to Home
                        Home();
                    }
                }
                else
                {
                    Console.WriteLine("\n\n   Cannot delete vehicle   \n +++++++++ Going back ++++++++++  \n  \n \n"); // If the customer is not modified , go back to the fleet menu. 
                    Fleet_Management();
                }
            }
            else if (choice == "4")
            {
                Fleet.Display_Vehicle(); // Accessing the Display_Vehicle from the Fleet_Management 
                Console.WriteLine("\n  Press \'H\' to go back Home or \'Q\' to Exit  Or \'B\' to go back \n");
                choice = Console.ReadLine();
                if (choice.ToUpper() == "H")
                {
                    Home();
                }
                else if (choice.ToUpper() == "B")
                {
                    Fleet_Management();
                }
                else if (choice.ToUpper() == "Q")
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("\n Please select a valid option ");
                    Fleet_Management();
                }
            }
            else if (choice.ToUpper() == "H" | choice.ToUpper() == "Q") // Checking if the user selects none of the options from (1,2,3,4) 
            {
                if (choice.ToUpper() == "H")
                {
                    Home();
                }
                else if (choice.ToUpper() == "Q")
                {
                    Environment.Exit(0);
                }
            }
            else
            {
                if (choice.ToUpper() == "H")
                {
                    Home();
                }
                else if (choice.ToUpper() == "Q")
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("\n Invalid option going back Home\n\n "); // If the option is still not valid , directly going back Home 
                    Home();
                }
            }
        }


        /// ///////////////////////////  Customer Management  ///////////////////////////////////////
        public void Customer_Management()
        {
            Console.WriteLine(menu2);
            choice = Console.ReadLine();
            if (choice == "1")
            {
                bool create = customer.Create_Customer(); // Accessing the Create_Customer() methd from CRM class 
                if (create == true)
                {
                    Console.WriteLine("\n  Press \'H\' to go back Home or \'B\' to go back or  \'Q\' to Exit \n"); // Asking for an option to go back Home or g back or  or quiting the program
                    choice = Console.ReadLine();
                    if (choice.ToUpper() == "H")
                    {
                        Home();
                    }
                    else if (choice.ToUpper() == "Q")
                    {
                        Environment.Exit(0);
                    }
                    else if (choice.ToUpper() == "B")
                    {
                        Customer_Management();
                    }
                    else
                    {
                        Console.WriteLine("\n Invalid Option \n \n Going back Home"); // If not a valid input going back to Home
                        Home();
                    }
                }
                else
                {
                    Console.WriteLine("\n\n  Cannot create customer \n +++++++++ Going back ++++++++++   \n \n");
                    Customer_Management();
                }
            }
            else if (choice == "2")
            {
                bool modify = customer.Modify_Customer(); // Accessing the Modify_Customer() from the CRM class
                if (modify == true)
                {
                    Console.WriteLine("\n  Press \'H\' to go back Home or \'B\' to go back or  \'Q\' to Exit \n"); // Asking for an option to go back Home or g back or  or quiting the program
                    choice = Console.ReadLine();
                    if (choice.ToUpper() == "H")
                    {
                        Home();
                    }
                    else if (choice.ToUpper() == "Q")
                    {
                        Environment.Exit(0);
                    }
                    else if (choice.ToUpper() == "B")
                    {
                        Customer_Management();
                    }
                    else
                    {
                        Console.WriteLine("\n Invalid Option \n \n Going back Home"); // If not a valid input going back to Home
                        Home();
                    }
                }
                else
                {
                    Console.WriteLine("\n\n Cannot modify customer \n  +++++++++ Going back ++++++++++   \n \n");
                    Customer_Management();
                }
            }
            else if (choice == "3")
            {
                bool delete = customer.Delete_Customer();
                if (delete == true)
                {
                    Console.WriteLine("\n  Press \'H\' to go back Home or \'B\' to go back or  \'Q\' to Exit \n"); // Asking for an option to go back Home or g back or  or quiting the program
                    choice = Console.ReadLine();
                    if (choice.ToUpper() == "H")
                    {
                        Home();
                    }
                    else if (choice.ToUpper() == "Q")
                    {
                        Environment.Exit(0);
                    }
                    else if (choice.ToUpper() == "B")
                    {
                        Customer_Management();
                    }
                    else
                    {
                        Console.WriteLine("\n Invalid Option \n \n Going back Home"); // If not a valid input going back to Home
                        Home();
                    }
                }
                else
                {
                    Console.WriteLine("\n\n  Cannot delete customer \n +++++++++ Going back ++++++++++   \n \n");
                    Customer_Management();
                }
            }
            else if (choice == "4")
            {
                customer.Display_Customer();
                // Asking for an option to go back Home or g back or  or quiting the program
                Console.WriteLine("\n  Press \'H\' to go back Home or \'B\' to go back or  \'Q\' to Exit \n");
                choice = Console.ReadLine();
                if (choice.ToUpper() == "H")
                {
                    Home();
                }
                else if (choice.ToUpper() == "Q")
                {
                    Environment.Exit(0);
                }
                else if (choice.ToUpper() == "B")
                {
                    Customer_Management();
                }
                else
                {
                    Console.WriteLine("\n Invalid Option \n \n Going back Home"); // If not a valid input going back to Home
                    Home();
                }
            }
            else
            {
                if (choice.ToUpper() == "H")
                {
                    Home();
                }
                else if (choice.ToUpper() == "Q")
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("\n Invalid option going back Home\n\n "); // If the option is still not valid , directly going back Home 
                    Home();
                }
            }// ending else statement 
        } // ending Customer_Management() 


        /// ///////////////////////////  Rental Management  ///////////////////////////////////////
        public void Rental_Management()
        {
            Console.WriteLine(menu3);
            choice = Console.ReadLine();
            if (choice == "1")
            {
                bool rent = rental.Rent_Vehicle(); // Accessing the Create_Customer() methd from CRM class 
                if (rent == true)
                {
                    Console.WriteLine("\n  Press \'H\' to go back Home or \'B\' to go back or  \'Q\' to Exit \n"); // Asking for an option to go back Home or g back or  or quiting the program
                    choice = Console.ReadLine();
                    if (choice.ToUpper() == "H")
                    {
                        Home();
                    }
                    else if (choice.ToUpper() == "Q")
                    {
                        Environment.Exit(0);
                    }
                    else if (choice.ToUpper() == "B")
                    {
                        Rental_Management();
                    }
                    else
                    {
                        Console.WriteLine("\n Invalid Option \n \n Going back Home"); // If not a valid input going back to Home
                        Rental_Management();
                    }
                }
                else
                {
                    Console.WriteLine("\n\n  Cannot Rent Vehicle  \n          +++++++++ Going back ++++++++++      \n \n");
                    Rental_Management();
                }
            }

            else if (choice == "2")
            {
                bool returned = rental.Return_Vehicle(); // Accessing the Modify_Customer() from the CRM class
                if (returned == true)
                {
                    Console.WriteLine("\n  Press \'H\' to go back Home or \'B\' to go back or  \'Q\' to Exit \n"); // Asking for an option to go back Home or g back or  or quiting the program
                    choice = Console.ReadLine();
                    if (choice.ToUpper() == "H")
                    {
                        Home();
                    }
                    else if (choice.ToUpper() == "Q")
                    {
                        Environment.Exit(0);
                    }
                    else if (choice.ToUpper() == "B")
                    {
                        Rental_Management();
                    }
                    else
                    {
                        Console.WriteLine("\n Invalid Option \n \n Going back Home"); // If not a valid input going back to Home
                        Home();
                    }
                }
                else
                {
                    Console.WriteLine("\n\n Cannot Return Vehicle \n  +++++++++ Going back ++++++++++   \n \n");
                    Rental_Management();
                }
            }
            else if (choice == "3")
            {
                rental.Search_Vehicle();
            }
            else if (choice == "4")
            {
                rental.Display_Rental();
                // Asking for an option to go back Home or g back or  or quiting the program
                Console.WriteLine("\n  Press \'H\' to go back Home or \'B\' to go back or  \'Q\' to Exit \n");
                choice = Console.ReadLine();
                if (choice.ToUpper() == "H")
                {
                    Home();
                }
                else if (choice.ToUpper() == "Q")
                {
                    Environment.Exit(0);
                }
                else if (choice.ToUpper() == "B")
                {
                    Rental_Management();
                }
                else
                {
                    Console.WriteLine("\n Invalid Option \n \n Going back Home"); // If not a valid input going back to Home
                    Home();
                }
            }
            else
            {
                if (choice.ToUpper() == "H")
                {
                    Home();
                }
                else if (choice.ToUpper() == "Q")
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("\n Invalid option going back Home\n\n "); // If the option is still not valid , directly going back Home 
                    Home();
                }
            }// ending else statement 
        } // ending Rental_Management() 
    }// ending class Menu_
}// end of namespace 
