﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;
using System.Windows.Markup;
namespace MRRCMANAGMEMENT
{
    /// <summary>
    /// 
    /// This class is created to read the file , make the conversion of data into comma separated file, and write the data into the files 
    /// ======================================================================================================================================
    /// String array paths : Gets the paths of the files from command line 
    /// =================================================================================================================================
    ///   string array data_ : stores the data from the files that are split by ','
    /// =====================================================================================================================================
    /// The list read_file is used to store the data while reading the file in the ReadFile() method 
    /// 
    /// The list csv_file is used to store the data recorded with ',' to be later written into the files 
    /// ====================================================================================================================================
    ///     
    ///   The class contains 5 methods :   
    ///   
    /// 1) Read_File(sting path) : reads file
    /// 
    /// 2) Csv_File(string [] a, int new_line) : Returns a comma separated ','
    ///                                         
    /// 3) WriteFile ( path , list added ) : This method takes the file path , to which the data (list added) is to be appended to. 
    /// 
    /// 4) Writefile_New ( path , list added ) : Works the same way as the WriteFile, although it does not append into the file.
    ///                                     It rewrites the whole file with the list provided  
    ///
    /// 5) Table (int i) : This helps in making a table when displaying the data on the interface . 
    ///
    /// ===================================================================================================================================
    ///
    /// It creates a boolean to make sure, that the program only executes itself if the file required exists 
    /// 
    /// </summary>
    /// 

    public class File_Manipulation
    {
        string[] paths = Environment.GetCommandLineArgs(); // get the command line arguments as file paths
        string[] data_;
        public string[] default_Path = { "", @"../../../Data/fleet.csv", @"../../../Data/customers.csv", @"../../../Data/rentals.csv" };
        bool proceed = true;
        List<string> read_file = new List<string>();
        List<string> csv_file = new List<string>();
        // Describing the properties that are used outside the class 
        public string[] Path
        {
            get { return paths; }
            set
            {
                if (Proceed == false)
                {
                    this.paths = default_Path;
                }
                else
                {
                    paths = value;
                }

            }
        }
        public List<string> Read_file
        {
            get { return read_file; }
        }
        public List<string> Csv_file
        {
            get { return csv_file; }
        }
        public bool Proceed
        {
            get { return proceed; }
            set { proceed = value; }
        }


        //`~~~~~~~~~ ReadFile : reads the file form the File_Path`~~~~~~~~~ 

        public void ReadFile(string File_Path)
        {
            if (!File.Exists(File_Path)) // if file does not exist use default paths
            {
                Console.WriteLine($"\n Error loading the  file : THE FILE {File_Path} DOES  NOT EXIST"); // tells if the file does not exists 
                Proceed = false;
                Console.WriteLine($"\n Using the following files \n Fleet : .. / .. / .. / Data / fleet.csv \n Customers:  .. / .. / .. / Data / customers.csv  \n Rentals : ../../.. /Data/rentals.csv \n \n ");

                this.paths = default_Path;

            }
            if (Proceed == true)
            {
                try// read the file
                {
                    StreamReader stream_ = new StreamReader(File_Path);
                    string line;
                    while ((line = stream_.ReadLine()) != null)
                    {
                        data_ = line.Split(',');
                        foreach (string var in data_)
                        {
                            Read_file.Add(var);
                        }
                    }
                    stream_.Close();
                }
                catch (Exception FILE)// catches exceptions except the file does not exist
                {
                    proceed = false;
                    Console.WriteLine(FILE.Message);
                }

            }


        }


        // `~~~~~~~~~ Csv_File : returns a comma seperated list with a \n for defining when to add the next line `~~~~~~~~~
        public List<String> Csv_File(string[] a, int new_line)
        {
            int i = 0;
            int len = a.Length;
            while (i < len)
            {
                int k = 0;
                for (; k < new_line; i++)
                {
                    if (i < len)
                    {
                        csv_file.Add(a[i]);
                        if (k < new_line - 1)
                        {
                            csv_file.Add(",");// Adding the comma 
                        }
                        k++;
                    }
                    else
                    {
                        break;
                    }
                }
                csv_file.Add("\n"); // Adding the newline character after the given int new_line
            }
            return Csv_file;
        }


        // `~~~~~~~~~WriteFile : Writes (appends)  the list a (Usually returned by Csv_File method) to teh file given by the path`~~~~~~~~~
        public void WriteFile(string file, List<string> added)
        {
            try
            {
                // create a list csv
                StreamWriter stream_ = new StreamWriter(file, true);
                foreach (string s in added)
                {
                    stream_.Write(s);
                }
                //stream_.Write("\n");
                stream_.Close();
            }
            catch (Exception file_exception)
            {

                Console.WriteLine(file_exception.Message);
            }
        }

        //`~~~~~~~~~ WriteFile_New : Writes a whole new list onto the file specified by the file path given`~~~~~~~~~
        public void WriteFile_New(string file, List<string> a)
        {
            if (!File.Exists(file))
            {
                Console.WriteLine("\n Error loading the  file: FILE DOES NOT EXIST");
                proceed = false;
            }
            else
            {
                StreamWriter stream_ = new StreamWriter(file, false);
                for (int i = 0; i < a.Count; i++)
                {
                    stream_.Write(a[i]);
                }
                stream_.Close();
            }
        }

        //`~~~~~~~~~ Table : helps describe a table with int i which helps determine when to print a row `~~~~~~~~~
        public string Table(int i)
        {
            int j = 0;
            string table_ = ("");
            for (j = 0; j < i; j++)
            {
                table_ = "= =";
                Console.Write(table_);
            }
            return table_;
        }

        //`~~~~~~~~~ Table : Overload on the previous method, displays all the content in the file in a tabular manner `~~~~~~~~~
        public void Table(List<string> file, int width_table, int attributes)
        {
            int width = ("  " + file[0] + "  ").Length; // initialising the width of the cell of the table
            Table(width_table * width);
            Console.WriteLine();
            int l = 0; int index = 0; int var = 0;
            while (var < file.Count)
            {
                for (; l < attributes; index++)
                {
                    if (index < file.Count)
                    {
                        // making sure the cells are of same size
                        width = Math.Abs(file[index].Length - (file[0].Length));
                        string width_ = "";
                        //making a string that is of the size of the difference between the ideal and the present width
                        for (int i = 0; i < width; i++)
                        {
                            width_ += " ";
                        }
                        Console.Write("  " + file[index] + width_ + " |");
                        l++;
                        width = ("  " + file[index] + width_ + " |").Length;
                    }
                    else
                    {
                        break;
                    }
                }
                Console.WriteLine();
                Table(width_table * width);
                l = 0;
                var += attributes;// updating the index for the loop by the number of  vehicle's attributes 
                Console.WriteLine();
            }

        }

        //`~~~~~~~~~ Method to create lists of specific attributes `~~~~~~~~~ 
        // int start : the index of the first attribute to be read 
        // int attributes : The increment of the for loop 
        // string path : the path of the file to be read

        public List<string> attributes_list(int path, int attributes, int start)
        {
            List<string> values_to_check = new List<string>();
            File_Manipulation File_read = new File_Manipulation();
            File_read.ReadFile(File_read.Path[path]);
            if (File_read.Proceed == false)
            {
                File_read.Proceed = true;
                File_read.ReadFile(File_read.Path[path]);

            }
            for (int index = start; index <= File_read.Read_file.Count - 1;)
            {
                values_to_check.Add(File_read.Read_file[index]);
                index = index + attributes;
            }
            return values_to_check;
        }
    }
}
