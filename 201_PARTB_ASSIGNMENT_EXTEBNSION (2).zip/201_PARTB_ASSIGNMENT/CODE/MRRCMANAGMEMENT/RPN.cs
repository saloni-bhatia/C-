﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using MRRCMANAGMEMENT;
using System.Security.AccessControl;

namespace myRPN
{
    /*  ACKNOWLEDGEMENT 

       The following code is directly taken from Shlomo Geva's code . A few changes have been done to replace 
       the hard=coded attributes 
   */

    /// </summary>
    /// 
    /// The following code's main function is to  use dijkstra algorithm using a stack 
    /// and to convert infix (given query) to postfix notation 
    /// 
    ///</summary>

    public class RPN
    {

        ArrayList operators; //  Stores the operators (Hard-coded)
        ArrayList operands; //  Stores the operands (Got from the file)
        public ArrayList Infix { get; } = new ArrayList(); // Infix - stores the input query 
        public ArrayList Postfix { get; } = new ArrayList();// Stores the Postfix after applying RPN 


        // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Method to Convert infix to postfix~~~~~~~~~~~~~~~~~~~~~`
        // Get the query entered as an ArrayList, Compare each element of the query using the dijkstra algorithm and form a postfix 
        public RPN(ArrayList query)
        {
            operators = new ArrayList();
            operands = new ArrayList();
            // hardcoded operators
            string[] operators_used = { "AND", "OR", "(", ")" }; // operators and parentheses
            operators.AddRange(operators_used);// adding them to the list for future reference 

            // define valid tokens from the file 
            // Getting operands using the attributes.list method of the File_Manipulation class 
            File_Manipulation operands_from_file = new File_Manipulation();

            // 12 = no of attributes of the vehicle in fleet file
            // Other numbers indicate the index of the first occurance of the required attribute 

            //colors
            List<string> Color = operands_from_file.attributes_list(1, 12, 23);
            //Model
            List<string> Model = operands_from_file.attributes_list(1, 12, 15);
            //Make
            List<string> Make = operands_from_file.attributes_list(1, 12, 14);
            //Grade
            List<string> Grade = operands_from_file.attributes_list(1, 12, 13);
            //no_of_seats
            List<string> No_OF_Seats = operands_from_file.attributes_list(1, 12, 17);
            //fuel
            List<string> Fuel = operands_from_file.attributes_list(1, 12, 19);
            //transmission
            List<string> Transmission = operands_from_file.attributes_list(1, 12, 18);
            //year
            List<string> Year = operands_from_file.attributes_list(1, 12, 16);

            // Adding each list formed abpve to teh operands list, after replacing the spaces.
            foreach (string element in Color)
            {
                operands.Add(element.ToUpper().Replace(" ", ""));
            }
            foreach (string element in Model)
            {
                operands.Add(element.ToUpper().Replace(" ", ""));
            }
            foreach (string element in Make)
            {
                operands.Add(element.ToUpper().Replace(" ", ""));
            }
            foreach (string element in Grade)
            {
                operands.Add(element.ToUpper().Replace(" ", ""));
            }
            foreach (string element in Fuel)
            {
                operands.Add(element.ToUpper().Replace(" ", ""));
            }
            foreach (string element in Transmission)
            {
                operands.Add(element.ToUpper().Replace(" ", ""));
            }
            foreach (string element in Year)
            {
                operands.Add(element.ToUpper().Replace(" ", "") + "-YEAR");
            }

            // Add other valid tokens
            operands.Add("SUNROOF");
            operands.Add("GPS");
            operands.Add("NOGPS");
            operands.Add("NOSUNROOF");
            // adding number of seats, since the highest number of seats allowed is 10, the list ends at 10. 
            string[] seats = { "1-SEATER", "2-SEATER", "3-SEATER", "4-Seater", "5-Seater", "6-Seater", "7-Seater", "8-Seater", "9-Seater", "10-Seater" };
            foreach (string element in seats)
            {
                operands.Add(element.ToUpper());
            }

            // Create and instantiate a new empty Stack.
            Stack rpnStack = new Stack();
            // apply dijkstra algorithm using a stack to convert infix to postfix notation (=rpn)
            Infix.AddRange(query);
            bool do_not_throw = false;// used to check if an exception in to be thrown or not 
            string unknown = "";// Stores unknown tokens in the query 
            string known = "";// Stores the known tokens 

            foreach (string token in Infix)
            {
                if (operands.Contains(token))
                {   // move operands across to output
                    Postfix.Add(token);
                    known = token;// store the known , this value is used later 
                    do_not_throw = true;// do not throw an exception for an unknown token, if even one token is known
                }
                else if (token.Equals("("))
                {   // push open parenthesis onto stack
                    rpnStack.Push(token);
                }
                else if (token.Equals(")"))
                {   // pop all operators off the stack until the mathcing open parenthesis is found
                    while ((rpnStack.Count > 0) && !((string)rpnStack.Peek()).Equals("("))
                    {
                        Postfix.Add(rpnStack.Pop());  // transfer operator to output
                        if (rpnStack.Count == 0)
                            throw new Exception("Ubalanced parenthesis");
                    }
                    if (rpnStack.Count == 0)
                        throw new Exception("Ubalanced parenthesis");
                    rpnStack.Pop(); // discard open parenthesis
                }
                else if (operators.Contains(token))
                {
                    if (Postfix.Count != 0)
                    {
                        // push operand to the rpn stack after moving to output all higher or equal priority operators
                        while (rpnStack.Count > 0 && ((string)rpnStack.Peek()).Equals("AND"))
                        {
                            Postfix.Add(rpnStack.Pop());  // pop and add to output
                        }
                        rpnStack.Push(token); // now push the operator onto the stack
                    }
                }
                else // unknown token 
                {
                    if (known.Length > 0)// if even one of the tokens in known
                    {
                        Postfix.Add(known);// add that token to Postfix again 
                    }
                    unknown += token; // store the unknown token to be displayed in the message later 
                }


            }
            if (do_not_throw)// if there were any known tokens  
            {
                if (unknown.Length > 0) // if we have unknown tokens 
                {
                    Console.WriteLine("Unknown token/tokens : " + unknown + " \n Results shown ignoring them");
                }
            }
            else// no known tokens were present.
            {
                throw new Exception("Unrecognised token " + unknown);
            }

            // now copy what's left on the rpnStack
            while (rpnStack.Count > 0)
            {   // move to the output all remaining operators
                if (((string)rpnStack.Peek()).Equals("("))
                    throw new Exception("Ubalanced parenthesis");
                Postfix.Add(rpnStack.Pop());
            }
        } // end RPN() constructor
    } //end Class RPN
}
