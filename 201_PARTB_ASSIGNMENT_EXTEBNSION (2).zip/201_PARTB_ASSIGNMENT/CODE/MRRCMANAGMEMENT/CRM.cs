﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCMANAGMEMENT
{
    /// <summary>
    /// 
    ///The class CRM helps create,modify,delete, display the customers
    ///It inherits from the Gender class to make sure that the inputs are correct and make the inputs easier 
    ///===========================================================================================================
    /// 
    /// This has 4 methods : 
    /// 
    /// 1) Create_Customer() : Creates a customer and return a bool . True : If the customer is created , False : If the creation was unsuccessful 
    /// 2) Modify_Customer() : Modifies a customer and returns a bool. True : If the customeris modified , False : If the modification was unsuccessful
    /// 3) Delete_Customer() : Deletes a customer and reeturns a bool . True : If the customer is deleted, False : If the deletion was unsuccessful 
    /// 4) Display_Customer() : Displays the customers  in the file 
    /// 
    /// /// ======================================================================================================================================
    /// It also describes a constant int to describe the number of attributes of the customer attributes 
    /// </summary>
    public class CRM : Gender
    {

        const int attributes_num_customer = 6;

        // -----------------------------------------------    CREATE CUSTOMER  -----------------------------------------//

        // The method reads the Customer file using the File_newanipulation() class asks for the inputs, 
        // checks if the inputs were correct , displays appropriate errors if any 
        // Writes to the file , if the inputs are correct and returns a bool. 



        public bool Create_Customer()
        {
            bool create_customers = true;
            File_Manipulation customer_file = new File_Manipulation();


            customer_file.ReadFile(customer_file.Path[2]); // Reading the file
            if (customer_file.Proceed == false)
            {
                customer_file.Proceed = true;
                customer_file.ReadFile(customer_file.Path[2]);

            }

            // Proceed only if file exists 
            if (customer_file.Proceed == true)
            {
                Console.Write("\n\n     || CREATE CUSTOMER ||    \n\n  +++ ENTER THE FOLLOWING DETAILS +++ \n\n ALL FIELDS ARE MANDATORY (*) \n\n  * Customer Id is set by default  * \n\n");
                Console.Write("1) Title* : ");
                string cust_title = Console.ReadLine();
                bool title = Int32.TryParse(cust_title, out int title_); // Checking if the value is int or not 
                Console.Write("2) Last Name* : ");
                string cust_lastName = Console.ReadLine();
                bool last_name = Int32.TryParse(cust_lastName, out int lastName);// Checking if the value is int or not 
                Console.Write("3) First Name* : ");
                string cust_firstName = Console.ReadLine();
                bool first_name = Int32.TryParse(cust_firstName, out int firstName);// Checking if the value is int or not 
                Console.Write("4) Gender ( 0: Male/ 1 : Female/ 2  :Other)*:");
                string cust_gender = Console.ReadLine();
                bool gender_ = Int32.TryParse(cust_gender, out int gender);// Checking if the value is an int  or not 
                Console.Write("5) Date Of Birth (dd/mm/yy)* : ");
                string cust_dateBirth = Console.ReadLine();
                bool date_ = DateTime.TryParse(cust_dateBirth, out DateTime dob_);// Checking if the value is a DateTime or not 

                Gender_ gender_enum = (Gender_)Convert.ToInt32(gender); // Converting into the Gender_ class 

                /// Checking for mandatory fields



                if (cust_title == "" | cust_lastName == "" | cust_firstName == "" | cust_gender == "" | cust_dateBirth == "")
                {
                    create_customers = false; // Setting the create bool to false if the mandatory fields are not provided

                    Console.WriteLine($"\n Fields marked * are mandatory \n");

                    if (cust_title == "")
                    {
                        Console.WriteLine("\n No title provided ");

                    }
                    if (cust_lastName == "")
                    {
                        Console.WriteLine("\n No Last Name provided ");

                    }
                    if (cust_firstName == "")
                    {
                        Console.WriteLine("\n No First Name provided ");

                    }
                    if (cust_gender == "")
                    {
                        Console.WriteLine("\n No gender provided ");

                    }
                    if (cust_dateBirth == "")
                    {
                        Console.WriteLine("\n No date of birth provided ");

                    }
                }
                // Checking for invalid inputs 

                else if (title | last_name | first_name | !gender_ | !date_)
                {
                    create_customers = false;

                    if (title)
                    {
                        Console.WriteLine($" \n ERROR : Invalid title {cust_title} ");

                    }
                    if (last_name)
                    {
                        Console.WriteLine($"\n ERROR : Invalid format for Last Name {cust_lastName}");

                    }
                    if (first_name)
                    {
                        Console.WriteLine($"\n ERROR : Invalid format for First Name {cust_firstName}");

                    }
                    if (!gender_)
                    {
                        Console.WriteLine($"\n ERROR : Invalid entry for Gender {cust_gender} Valid enteries (0: Male,1: Female, 2: Other)");

                    }
                    if (!date_)
                    {
                        Console.WriteLine($"\n ERROR : Invalid format for  date of birth {cust_dateBirth} Accepted format (dd/mm/yy)");

                    }
                }

                else
                {

                    if (create_customers == true)
                    {
                        // Checking if the gender input is valid 
                        if (gender_enum == Gender_.Male | gender_enum == Gender_.Female | gender_enum == Gender_.Other)

                        {
                            create_customers = true;
                        }
                        else

                        {
                            create_customers = false;
                            Console.WriteLine($"\n ERROR : Invalid entry {cust_gender} Valid enteries (0 : Male, 1: Female, 2: Other)");
                        }
                    }


                }
                if (create_customers == true)
                {
                    // Creating the default id by creating an object of the Customer class 

                    Customer C1 = new Customer();

                    // Creating an array with the attributes 

                    string[] attributes = { C1.Cust_Id.ToString(), cust_title, cust_lastName, cust_firstName, gender_enum.ToString(), cust_dateBirth };

                    // Writing to a file 
                    List<String> a = customer_file.Csv_File(attributes, C1.cust_attributes);

                    customer_file.WriteFile(customer_file.Path[2], a);

                    Console.WriteLine("\n  The customer was added ! \n");

                    customer_file.Table(4 * (attributes.Length));// Displaying the customer create 
                    Console.WriteLine();
                    Console.Write(" ");

                    for (int i = 0; i < attributes.Length; i++)
                    {
                        Console.Write(attributes[i] + "   ");

                    }

                    Console.WriteLine();
                    customer_file.Table(4 * (attributes.Length));

                }// end (if (create ==true)

            }// end if (proceed == true)

            else
            {
                create_customers = false;
                Console.WriteLine($"The FILE at {customer_file.Path[2]} does not exist");
            }
            return (create_customers);


        }// end Create_Customer()


        // -----------------------------------------------    MODIFY CUSTOMER  -----------------------------------------//




        // The method reads the Customer file using the File_newanipulation() class asks for the inputs, 
        // checks if the inputs were correct , displays appropriate errors if any 
        // Writes to the file , if the inputs are correct and returns a bool. 
        public bool Modify_Customer()
        {

            File_Manipulation customer_file = new File_Manipulation();


            bool modify_customer = false;
            bool id_found = false;
            customer_file.ReadFile(customer_file.Path[2]); // setting default paths, if file does not exist
            if (customer_file.Proceed == false)
            {
                customer_file.Proceed = true;
                customer_file.ReadFile(customer_file.Path[2]);
            }

            // proceed only if the file exists 

            if (customer_file.Proceed == true)
            {
                int length_ = customer_file.Read_file.Count;
                Console.Write("\n\n   || MODIFYING A CUSTOMER ||    \n\n Enter the Customer Id for the customer to be modified  : ");
                string cust_id = Console.ReadLine();
                bool id = Int32.TryParse(cust_id, out int id_);
                // Checking if the id is not an int 
                if (!id)
                {
                    modify_customer = false;
                    Console.WriteLine($"\n ERROR : Invalid customer Id {cust_id}");
                }
                else
                {
                    // Checking if the given customer id is a part of the file 
                    for (int c_ids = 0; c_ids < length_ - 1;)
                    {
                        if (customer_file.Read_file[c_ids] == cust_id)
                        {
                            id_found = true;
                            modify_customer = true;
                            Console.WriteLine($"\n The customer Id {cust_id} found");
                            int end = c_ids + attributes_num_customer; // Establishing the end of the loop  at the last attribute 
                            customer_file.Table(3 * attributes_num_customer);
                            Console.WriteLine();
                            // Adding the original attributes of the selected customer into an array 
                            string[] data_old = new string[attributes_num_customer];
                            int i = 0;
                            for (; c_ids < end; c_ids++)
                            {
                                data_old[i] = customer_file.Read_file[c_ids];
                                Console.Write(customer_file.Read_file[c_ids] + "  ");
                                i++;
                            }
                            // Displaying the attributes of the customer selected 
                            Console.WriteLine();
                            customer_file.Table(3 * attributes_num_customer);
                            c_ids -= attributes_num_customer;

                            if (modify_customer == true)
                            {
                                // Asking for the changes needed 
                                // Using the same method to see the inputs are valid or not as used in Create_Customer() class
                                Console.WriteLine("\n Type the attributes you want to modify , leave the space blank for the attributes not being modified.\n");
                                Console.Write("1) Customer ID : ");
                                string cust_id_new = Console.ReadLine();
                                bool id_modify = Int32.TryParse(cust_id_new, out int id_new);
                                Console.Write("2) Title : ");
                                string cust_title_new = Console.ReadLine();
                                bool title = Int32.TryParse(cust_title_new, out int title_new);
                                Console.Write("3) Last Name : ");
                                string cust_lastName_new = Console.ReadLine();
                                bool last_name_new = Int32.TryParse(cust_lastName_new, out int lastName_new);
                                Console.Write("4) First Name : ");
                                string cust_firstName_new = Console.ReadLine();
                                bool first_name_new = Int32.TryParse(cust_firstName_new, out int firstName_new);
                                Console.Write("5) Gender ( 0 : Male/ 1 : Female/ 2 : Other):");
                                string cust_gender_new = Console.ReadLine();
                                bool gender__new = Int32.TryParse(cust_gender_new, out int gender_new);
                                Console.Write("attributes_num_customer) Date Of Birth (dd/mm/yy) : ");
                                string cust_dateBirth_new = Console.ReadLine();
                                bool date_new = DateTime.TryParse(cust_dateBirth_new, out DateTime dob_new);
                                Gender_ gender_enum = (Gender_)Convert.ToInt32(gender_new);

                                // Setting the attributes as the original ones if no new inputs are given 
                                if (cust_id_new == "" | cust_title_new == "" | cust_id_new == "" | cust_lastName_new == "" | cust_firstName_new == "" | cust_gender_new == "" | cust_dateBirth_new == "")
                                {
                                    if (cust_id_new == "")
                                    {
                                        cust_id_new = data_old[0];
                                    }
                                    if (cust_title_new == "")
                                    {
                                        cust_title_new = data_old[1];
                                    }
                                    if (cust_lastName_new == "")
                                    {
                                        cust_lastName_new = data_old[2];
                                    }
                                    if (cust_firstName_new == "")
                                    {
                                        cust_firstName_new = data_old[3];
                                    }
                                    if (cust_gender_new == "")
                                    {
                                        cust_gender_new = data_old[4];
                                    }
                                    if (cust_dateBirth_new == "")
                                    {
                                        cust_dateBirth_new = data_old[5];
                                    }
                                }
                                // Checking if the inputs are valid 

                                if (!id_modify | title | last_name_new | first_name_new | !gender__new | !date_new)
                                {
                                    if (!id_modify & cust_id_new != data_old[0])
                                    {
                                        modify_customer = false;
                                        Console.WriteLine($"\n ERROR : Invalid customer Id {cust_id}");
                                    }

                                    if (title & cust_title_new != data_old[1])
                                    {
                                        modify_customer = false;
                                        Console.WriteLine($" \n ERROR : Invalid title {cust_title_new} ");

                                    }

                                    if (last_name_new & cust_lastName_new != data_old[2])
                                    {

                                        modify_customer = false;
                                        Console.WriteLine($"\n ERROR : Invalid format for Last Name {cust_lastName_new}");

                                    }

                                    if (first_name_new & cust_firstName_new != data_old[3])
                                    {
                                        modify_customer = false;
                                        Console.WriteLine($"\n ERROR : Invalid format for First Name {cust_firstName_new}");
                                    }

                                    if (!gender__new & cust_gender_new != data_old[4])
                                    {
                                        modify_customer = false;
                                        Console.WriteLine($"\n ERROR : Invalid entry {cust_gender_new} Valid enteries (0: Male, 1: Female, 2: Other)");

                                    }

                                    if (!date_new & cust_dateBirth_new != data_old[5])
                                    {
                                        Console.WriteLine($"\n ERROR : Invalid format for  date of birth {cust_dateBirth_new} Accepted format (dd/mm/yy)");
                                        modify_customer = false;

                                    }
                                }

                                if (modify_customer == true)
                                {
                                    if (cust_id_new != data_old[0]) // if a new cust id is given check if the new one is UNIQUE 
                                    {
                                        for (int c_id = 0; c_id < customer_file.Read_file.Count - 1; c_id += attributes_num_customer)
                                        {

                                            if (customer_file.Read_file[c_id] == cust_id_new)
                                            {
                                                // Same value is allowed 
                                                if (cust_id_new != data_old[0])
                                                {
                                                    modify_customer = false;
                                                    Console.WriteLine($"\n The customer id {cust_id_new} already exists !"); // Display if the cust id was not unique 
                                                    break;
                                                }
                                                else
                                                {
                                                    modify_customer = false;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    if (cust_gender_new != data_old[4])
                                    {

                                        // Checking for correct Gender input 
                                        if (gender_enum == Gender_.Male | gender_enum == Gender_.Female | gender_enum == Gender_.Other)
                                        {
                                            modify_customer = true;
                                        }
                                        else
                                        {
                                            modify_customer = false;
                                            Console.WriteLine($"\n ERROR : Invalid entry {gender_new} Valid enteries (0 : Male, 1: Female, 2: Other)");
                                        }
                                    }
                                    if (cust_dateBirth_new != data_old[5])
                                    {
                                        // checki gofr ci=orrect dob format 
                                        if (!date_new)
                                        {
                                            Console.WriteLine($"\n Invalid date of birth {cust_dateBirth_new}");
                                            modify_customer = false;
                                        }
                                    }

                                }
                                if (modify_customer == true)
                                {

                                    // Making an array of the new attributes to display and enter into the file

                                    string[] attributes = { cust_id_new, cust_title_new, cust_lastName_new, cust_firstName_new, gender_enum.ToString(), cust_dateBirth_new };

                                    // Changing the data into the file

                                    for (int new_ = 0; new_ < data_old.Length; new_++)
                                    {
                                        data_old[new_] = attributes[new_];
                                        customer_file.Read_file[c_ids] = data_old[new_];
                                        c_ids++;

                                    }

                                    // Writing into the file 

                                    List<String> attributes_added = new List<String>();

                                    attributes_added = customer_file.Csv_File(customer_file.Read_file.ToArray(), attributes_num_customer);

                                    customer_file.WriteFile_New(customer_file.Path[2], attributes_added);

                                    Console.WriteLine("\n  The customer was modified ! \n");

                                    // Displaying the new modified customer data 
                                    customer_file.Table(4 * (attributes.Length));
                                    Console.WriteLine();
                                    Console.Write(" ");

                                    for (int att_ = 0; att_ < attributes.Length; att_++)
                                    {
                                        Console.Write(data_old[att_] + "   ");


                                    }

                                    Console.WriteLine();
                                    customer_file.Table(4 * (attributes.Length));
                                    Console.WriteLine();

                                }
                            }
                            break;
                        }
                        else
                        {
                            id_found = false;
                        }

                        c_ids += attributes_num_customer;// Updating the index of the loop wth the number of the attributes of the customer class to read ids

                    }

                    if (id_found == false)
                    {
                        Console.WriteLine($"Customer Id {cust_id} not found!");
                    }


                }// end of else statement 


            }// end of if (customer_file.Proceed == true)

            else

            {
                modify_customer = false;
                Console.WriteLine($"The FILE at {customer_file.Path[2]} does not exist");
            }

            return modify_customer;

        }//End Moify_Customer()



        // -----------------------------------------------   DELETE CUSTOMER  -----------------------------------------//
        // The method reads the Customer file using the File_newanipulation() class asks for the inputs,
        // checks if the inputs were correct , displays appropriate errors if any 
        // Writes to the file ,  returns a bool.

        public bool Delete_Customer()
        {
            File_Manipulation customer_file = new File_Manipulation();
            customer_file.ReadFile(customer_file.Path[2]);
            if (customer_file.Proceed == false)
            {
                customer_file.Proceed = true;
                customer_file.ReadFile(customer_file.Path[2]);
            }
            bool delete_customer = false; // boolean returned to establish success / failure 
            bool id_found = true;

            // proceed only if the file exists 

            if (customer_file.Proceed == true)
            {

                Console.WriteLine("\n\n   || DELETE CUSTOMER ||    \n\n");

                Console.Write("Enter the customer Id of the customer to be deleted : ");
                string cust_id = Console.ReadLine();

                // Checkig if the data format is correct 

                bool id = Int32.TryParse(cust_id, out int id_);
                if (!id | cust_id == "")


                {
                    while (delete_customer != false)
                    {
                        // making sure that the cust_id is in the correct format 

                        if (!id)
                        {
                            Console.WriteLine($"\n The ID {cust_id} is not in the correct format");
                            delete_customer = false;
                        }

                        else
                        {
                            Console.Write($"\n Please enter a valid customer Id :");
                            cust_id = Console.ReadLine();

                            id = Int32.TryParse(cust_id, out id_);
                            delete_customer = true;

                        }
                    }

                } // end if 

                else
                {
                    // Search id cust_id exists in the data base for being sure the id is in the database

                    int len = customer_file.Read_file.Count;

                    // read the rental file 
                    File_Manipulation rentals = new File_Manipulation();
                    // Defining an int to go thriugh the rental file 
                    int rental_vehicle = 1;
                    // bool to make sure that the cust is not rennting a vehicle
                    bool is_renting = false;
                    rentals.ReadFile(rentals.Path[3]);
                    if (rentals.Proceed == false)
                    {
                        rentals.Proceed = true;
                        rentals.ReadFile(rentals.Path[3]);

                    }
                    for (int c_ids = 0; c_ids < len - 1;)
                    {

                        if (customer_file.Read_file[c_ids] == cust_id)
                        {

                            for (; rental_vehicle <= rentals.Read_file.Count() - 1;)
                            {
                                if (rentals.Read_file[rental_vehicle] != cust_id)
                                {
                                    delete_customer = true;
                                }
                                else
                                {
                                    delete_customer = false;
                                    is_renting = true;
                                    Console.WriteLine($" \n Cannot delete Customer . Customer {cust_id} is renting a vehicle.");
                                }
                                rental_vehicle += 2; // updating the index for the rental file
                            }

                            if (is_renting != true)
                            {
                                id_found = true;
                                string[] data = new string[attributes_num_customer];
                                Console.WriteLine($"\n The customer with customer id {cust_id} was found ! ");
                                // Displaying the details of the customer to be deleted  and adding it into an array for further use// 

                                customer_file.Table(3 * attributes_num_customer);
                                Console.WriteLine();

                                for (int disp = 0; disp < attributes_num_customer; disp++)
                                {
                                    Console.Write(customer_file.Read_file[c_ids] + " ");
                                    data[disp] = customer_file.Read_file[c_ids];
                                    c_ids++;
                                }

                                Console.WriteLine();

                                customer_file.Table(3 * attributes_num_customer);

                                Console.WriteLine();

                                c_ids -= attributes_num_customer;// getting the c_ids back after displaying ; 

                                // Confirming deletion 
                                Console.Write($"\n Are you sure you want to delete the customer {cust_id} ? (Y : YES ; N : NO) ");

                                string confirm = Console.ReadLine();

                                if (confirm.ToUpper() == "Y")
                                {
                                    customer_file.Read_file.RemoveRange(c_ids, attributes_num_customer); // Removing the data from the file 

                                    // Writing to the file 
                                    List<String> a = new List<String>();


                                    a = customer_file.Csv_File(customer_file.Read_file.ToArray(), attributes_num_customer);

                                    customer_file.WriteFile_New(customer_file.Path[2], a);
                                    Console.WriteLine("\n The customer was deleted !");
                                    break;

                                }
                                else if (confirm.ToUpper() == "N")
                                {
                                    delete_customer = false;
                                    break;

                                }

                            }
                        }

                        else
                        {
                            delete_customer = false;
                            id_found = false;

                        }
                        c_ids += attributes_num_customer; // updating the index of the loop by the number of attributes in the customer class


                    }

                    if (id_found == false && is_renting != true)
                    {
                        delete_customer = false;

                        Console.WriteLine($" \n Customer Id {cust_id} not found !\n ");
                    }

                }// end of else statement 

            } // end of checking the proceed statemet 

            else

            {
                delete_customer = false;
                Console.WriteLine($"The FILE at {customer_file.Path[2]} does not exist");
            }

            return delete_customer;

        }// end Delete_Customer()



        // -----------------------------------------------    DISPLAY CUSTOMER  -----------------------------------------//


        // The method reads the fleet file using the File_newanipulation() class and displays them in a table 

        public void Display_Customer()
        {
            // reading the file 

            File_Manipulation customer_file = new File_Manipulation();
            customer_file.ReadFile(customer_file.Path[2]);
            if (customer_file.Proceed == false)
            {
                customer_file.Proceed = true;
                customer_file.ReadFile(customer_file.Path[2]);

            }
            // Proceed only if the file exists 
            if (customer_file.Proceed)
            {
                // Forming a table
                int keep_track = 0; int index = 0; int attributes_newax = 0;
                int len = (customer_file.Read_file.Count);

                if (len <= 1)
                {
                    Console.WriteLine("\n There are no customers stored \n");
                }

                else
                {
                    int width = ("  " + customer_file.Read_file[2] + "   ").Length; // Initialising a cell width 

                    customer_file.Table(2 * width);

                    Console.WriteLine();

                    while (keep_track < len)
                    {

                        for (; attributes_newax < attributes_num_customer; index++)
                        {
                            if (index < len)
                            {
                                width = Math.Abs(customer_file.Read_file[index].Length - (customer_file.Read_file[2].Length)); //Making sure the cell width remains const
                                string width_ = "";
                                for (int i = 0; i < width; i++)
                                {
                                    width_ += " ";
                                }
                                Console.Write("  " + customer_file.Read_file[index] + width_ + "  " + "|");
                                attributes_newax++;

                            }
                            else
                            {
                                break;
                            }

                        }// end for loop 

                        Console.WriteLine();
                        customer_file.Table(2 * ("  " + customer_file.Read_file[2] + "   ").Length);
                        attributes_newax = 0;

                        keep_track += attributes_num_customer; // updating the loop index by the number of attributes of the customer 


                        Console.WriteLine();

                    }


                }// End of else statement 

            }// End of checking if the file exists 

            else

            {

                Console.WriteLine($"The FILE at {customer_file.Path[2]} does not exist \n\n Cannot display customers");
            }

        }// end of Delete_Customer()


    }// end of class 


}//end of namespace 

