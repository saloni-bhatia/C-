﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MRRCMANAGMEMENT;


namespace MRRC
{/// <summary>
/// The main program starts by printing a wekcome message and then going to the Menu_ class and printing the first menu 
/// </summary>
    class Program
    {
        
        static void Main(string[] args)

        {
        
             Menu_ menu = new Menu_(); // Creatig an object to access the Menu_ class's Home() method 

            Console.WriteLine("\n\n                     WELCOME TO MATES - RATES  : RENT A CAR           " +
                "      \n\n  Select an option to continue and press ENTER after every input .  You may enter  'h' to go back to the \"Home\" menu or 'Q' to QUIT  \n\n");

            

            menu.Home();



        }//end of Main
    }//End of class Program
}// End of namespace MRRC 
